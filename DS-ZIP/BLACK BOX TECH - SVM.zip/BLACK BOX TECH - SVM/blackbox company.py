import pandas as pd
import numpy as np



train_raw = pd.read_csv(r"D:\Desktop\DATA SCIENCE\BLACK BOX TECH - SVM\Datasets_SVM\SalaryData_Train (1).csv")
train = train_raw.drop(['workclass','maritalstatus','relationship','race','sex','native'],axis='columns')



test_raw = pd.read_csv(r"D:\Desktop\DATA SCIENCE\BLACK BOX TECH - SVM\Datasets_SVM\SalaryData_Test (1).csv")
test_raw.describe()
test_raw.columns

test = train_raw.drop(['workclass','maritalstatus','relationship','race','sex','native'],axis='columns')


from sklearn.preprocessing import LabelEncoder
lb =LabelEncoder()

train.info()
train['education'] = lb.fit_transform(train['education'])
train['occupation'] = lb.fit_transform(train['occupation'])
train['Salary'] = lb.fit_transform(train['Salary'])

test.info()

test['education'] = lb.fit_transform(test['education'])
test['occupation'] = lb.fit_transform(test['occupation'])
test['Salary'] = lb.fit_transform(test['Salary'])

train['education']=lb.fit_transform(train['education'])

from sklearn.svm import SVC


train_X = train.iloc[:, 0:7]
train_y = train.iloc[:, 7]
test_X  = test.iloc[:, 0:7]
test_y  = test.iloc[:, 7]


# kernel = linear
help(SVC)
model_linear = SVC(kernel = "linear")
model_linear.fit(train_X, train_y)
pred_test_linear = model_linear.predict(test_X)

np.mean(pred_test_linear == test_y)

# kernel = rbf
model_rbf = SVC(kernel = "rbf")
model_rbf.fit(train_X, train_y)
pred_test_rbf = model_rbf.predict(test_X)

np.mean(pred_test_rbf==test_y)

