import pandas as pd
import numpy as np



fire_raw = pd.read_csv(r"D:\Desktop\DATA SCIENCE\BLACK BOX TECH - SVM\Datasets_SVM\forestfires.csv")

fire = fire_raw.iloc[:,2:]


from sklearn.preprocessing import LabelEncoder
lb =LabelEncoder()


fire['size_category'] = lb.fit_transform(fire['size_category'])
pd.value_counts(fire['size_category'])



#converting float values to integers
fire=fire.astype(int)


from sklearn.svm import SVC
from sklearn.model_selection import train_test_split

train,test = train_test_split(fire, test_size = 0.20)

train_X = train.iloc[:, 1:]
train_y = train.iloc[:, 0]
test_X  = test.iloc[:, 1:]
test_y  = test.iloc[:, 0]

fire=fire.astype(int)

# kernel = linear
help(SVC)
model_linear = SVC(kernel = "linear")
model_linear.fit(train_X, train_y)
pred_test_linear = model_linear.predict(test_X)

np.mean(pred_test_linear == test_y)

# kernel = rbf
model_rbf = SVC(kernel = "rbf")
model_rbf.fit(train_X, train_y)
pred_test_rbf = model_rbf.predict(test_X)

np.mean(pred_test_rbf==test_y)

