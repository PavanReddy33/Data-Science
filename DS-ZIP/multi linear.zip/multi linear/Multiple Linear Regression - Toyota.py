import pandas as pd   
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import pylab

toyota = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/20- Multiple Linear Regression/Assignments/Dataset/ToyotaCorolla.csv")
toyota.columns

toyota.drop(["Id"], axis=1, inplace = True)
toyota.drop(["Model"], axis=1, inplace = True)
toyota.drop(["Mfg_Month"], axis=1, inplace = True)
toyota.drop(["Mfg_Year"], axis=1, inplace = True)
toyota.drop(["Fuel_Type"], axis=1, inplace = True)
toyota.drop(["Met_Color"], axis=1, inplace = True)
toyota.drop(["Color"], axis=1, inplace = True)
toyota.drop(["Automatic"], axis=1, inplace = True)
toyota.drop(["Cylinders"], axis=1, inplace = True)
toyota.drop(["Color"], axis=1, inplace = True)

############### EDA ---> First Moment Business ##############

toyota.mean()
toyota.median()
toyota.mode()

############### EDA ---> Second Moment Business ##############

toyota.var()
toyota.std()
    
############### EDA ---> Third Moment Business #############

toyota.skew()

############### EDA ---> Fourth Moment Business #############

toyota.kurt()

############### EDA ---> Fifth Moment Business #############

plt.boxplot(toyota.Price)
plt.boxplot(toyota.Age0804)
plt.boxplot(toyota.KM)
plt.boxplot(toyota.HP)
plt.boxplot(toyota.cc)
plt.boxplot(toyota.Doors)
plt.boxplot(toyota.Gears)
plt.boxplot(toyota.QuarterlyTax)
plt.boxplot(toyota.Weight)


plt.hist(toyota.Price)
plt.hist(toyota.Age0804)
plt.hist(toyota.KM)
plt.hist(toyota.HP)
plt.hist(toyota.cc)
plt.hist(toyota.Doors)
plt.hist(toyota.Gears)
plt.hist(toyota.QuarterlyTax)
plt.hist(toyota.Weight)


 
plt.scatter(x = toyota["cc"], y = toyota["Age0804"], color = 'green') 
plt.scatter(x = toyota["KM"], y = toyota["Price"], color = 'green') 

sns.jointplot(x=toyota['cc'], y=toyota['Doors'])
sns.countplot(toyota['Gears'])
stats.probplot(toyota.Price, dist = "norm", plot = pylab),plt.show()
sns.pairplot(toyota.iloc[:, :9])

# Correlation matrix 
toyota.corr()

# preparing model considering all the variables 
import statsmodels.formula.api as smf
         
ml1 = smf.ols('Price ~ Age0804 + KM + HP + cc + Doors + Gears + QuarterlyTax + Weight', data = toyota).fit() 
ml1.summary()

# Checking whether data has any influential values 
# Influence Index Plots
import statsmodels.api as sm

sm.graphics.influence_plot(ml1)

toyotanew = toyota.drop(toyota.index[[80]])
toyotanew.columns
# Preparing model                  
ml_new = smf.ols('Price ~ Age0804 + KM + HP + cc + Doors + Gears + QuarterlyTax + Weight', data = toyotanew).fit()    

# Summary
ml_new.summary()


# Check for Colinearity to decide to remove a variable using VIF
# Assumption: VIF > 10 = colinearity
# calculating VIF's values of independent variables
rsq_hp = smf.ols('Price ~ Age0804 + KM + HP + cc + Doors + Gears + QuarterlyTax + Weight', data = toyota).fit().rsquared  
vif_hp = 1/(1 - rsq_hp) 

rsq_wt = smf.ols('Price ~ Age0804 + KM + HP + cc + Doors + Gears + QuarterlyTax + Weight', data = toyota).fit().rsquared  
vif_wt = 1/(1 - rsq_wt)

rsq_vol = smf.ols('Price ~ Age0804 + KM + HP + cc + Doors + Gears + QuarterlyTax + Weight', data = toyota).fit().rsquared  
vif_vol = 1/(1 - rsq_vol) 

rsq_sp = smf.ols('Price ~ Age0804 + KM + HP + cc + Doors + Gears + QuarterlyTax + Weight', data = toyota).fit().rsquared  
vif_sp = 1/(1 - rsq_sp) 


# Final model
final_ml = smf.ols('Price ~ Age0804 + KM + HP + cc + Doors + Gears + QuarterlyTax + Weight', data = toyota).fit()
final_ml.summary() 

# Prediction
pred = final_ml.predict(toyota)

# Q-Q plot
res = final_ml.resid
sm.qqplot(res)
plt.show()

# Q-Q plot
stats.probplot(res, dist = "norm", plot = pylab)
plt.show()

# Residuals vs Fitted plot
sns.residplot(x = pred, y = toyota.Price, lowess = True)
plt.xlabel('Fitted')
plt.ylabel('Residual')
plt.title('Fitted vs Residual')
plt.show()

sm.graphics.influence_plot(final_ml)


### Splitting the data into train and test data 
from sklearn.model_selection import train_test_split
import numpy as np

toyota_train, toyota_test = train_test_split(toyota, test_size = 0.2)

# preparing the model on train data 
model_train = smf.ols("Price ~ Age0804 + KM + HP + cc + Doors + Gears + QuarterlyTax + Weight", data = toyota_train).fit()

# prediction on test data set 
test_pred = model_train.predict(toyota_test)

# test residual values 
test_resid = test_pred - toyota_test.Price
# RMSE value for test data 
test_rmse = np.sqrt(np.mean(test_resid * test_resid))
test_rmse


# train_data prediction
train_pred = model_train.predict(toyota_train)

# train residual values 
train_resid  = train_pred - toyota_train.Price
# RMSE value for train data 
train_rmse = np.sqrt(np.mean(train_resid * train_resid))
train_rmse