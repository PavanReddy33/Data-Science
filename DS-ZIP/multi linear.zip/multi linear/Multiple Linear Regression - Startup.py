import pandas as pd   
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import pylab

startup = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/20- Multiple Linear Regression/Assignments/Dataset/50_Startups.csv")
startup.columns
startup = startup.drop(["State"], axis = 1)

############### EDA ---> First Moment Business ##############

startup.mean()
startup.median()
startup.mode()

############### EDA ---> Second Moment Business ##############

startup.var()
startup.std()
max(startup["R&DSpend"])-min(startup["R&DSpend"])
max(startup["Administration"])-min(startup["Administration"])
max(startup["MarketingSpend"])-min(startup["MarketingSpend"])
max(startup["Profit"])-min(startup["Profit"])
    
############### EDA ---> Third Moment Business #############

startup.skew()

############### EDA ---> Fourth Moment Business #############

startup.kurt()

############### EDA ---> Fifth Moment Business #############

plt.boxplot(startup)
plt.hist(startup) 
plt.scatter(x = startup["R&DSpend"], y = startup["Administration"], color = 'green') 
plt.scatter(x = startup["MarketingSpend"], y = startup["Profit"], color = 'green') 

sns.jointplot(x=startup['MarketingSpend'], y=startup['R&DSpend'])
sns.countplot(startup['MarketingSpend'])
stats.probplot(startup.Profit, dist = "norm", plot = pylab),plt.show()
sns.pairplot(startup.iloc[:, :])

# Correlation matrix 
startup.corr()

# preparing model considering all the variables 
import statsmodels.formula.api as smf
         
ml1 = smf.ols('Profit ~ RDSpend + Administration + MarketingSpend', data = startup).fit() 

# Summary
ml1.summary()

# Checking whether data has any influential values 
# Influence Index Plots
import statsmodels.api as sm

sm.graphics.influence_plot(ml1)

startupnew = startup.drop(startup.index[[49]])
startupnew.columns
# Preparing model                  
ml_new = smf.ols('Profit ~ RDSpend + Administration + MarketingSpend', data = startupnew).fit()    

# Summary
ml_new.summary()

# Check for Colinearity to decide to remove a variable using VIF
# Assumption: VIF > 10 = colinearity
# calculating VIF's values of independent variables
rsq_hp = smf.ols('Profit ~ RDSpend + Administration + MarketingSpend', data = startup).fit().rsquared  
vif_hp = 1/(1 - rsq_hp) 

rsq_wt = smf.ols('Profit ~ RDSpend + Administration + MarketingSpend', data = startup).fit().rsquared  
vif_wt = 1/(1 - rsq_wt)

rsq_vol = smf.ols('Profit ~ RDSpend + Administration + MarketingSpend', data = startup).fit().rsquared  
vif_vol = 1/(1 - rsq_vol) 

rsq_sp = smf.ols('Profit ~ RDSpend + Administration + MarketingSpend', data = startup).fit().rsquared  
vif_sp = 1/(1 - rsq_sp) 


# Final model
final_ml = smf.ols('Profit ~ RDSpend + Administration + MarketingSpend', data = startup).fit()
final_ml.summary() 

# Prediction
pred = final_ml.predict(startup)

# Q-Q plot
res = final_ml.resid
sm.qqplot(res)
plt.show()

# Q-Q plot
stats.probplot(res, dist = "norm", plot = pylab)
plt.show()

# Residuals vs Fitted plot
sns.residplot(x = pred, y = startup.Profit, lowess = True)
plt.xlabel('Fitted')
plt.ylabel('Residual')
plt.title('Fitted vs Residual')
plt.show()

sm.graphics.influence_plot(final_ml)


### Splitting the data into train and test data 
from sklearn.model_selection import train_test_split
import numpy as np

startup_train, startup_test = train_test_split(startup, test_size = 0.2)

# preparing the model on train data 
model_train = smf.ols("Profit ~ RDSpend + Administration + MarketingSpend", data = startup_train).fit()

# prediction on test data set 
test_pred = model_train.predict(startup_test)

# test residual values 
test_resid = test_pred - startup_test.Profit
# RMSE value for test data 
test_rmse = np.sqrt(np.mean(test_resid * test_resid))
test_rmse


# train_data prediction
train_pred = model_train.predict(startup_train)

# train residual values 
train_resid  = train_pred - startup_train.Profit
# RMSE value for train data 
train_rmse = np.sqrt(np.mean(train_resid * train_resid))
train_rmse
















