import pandas as pd   
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import pylab

avocado = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/20- Multiple Linear Regression/Assignments/Dataset/Avacado_Price.csv")
avocado.columns

avocado.drop(["type"], axis=1, inplace = True)
avocado.drop(["year"], axis=1, inplace = True)
avocado.drop(["region"], axis=1, inplace = True)

avocado.columns
############### EDA ---> First Moment Business ##############

avocado.mean()
avocado.median()
avocado.mode()

############### EDA ---> Second Moment Business ##############

avocado.var()
avocado.std()
    
############### EDA ---> Third Moment Business #############

avocado.skew()

############### EDA ---> Fourth Moment Business #############

avocado.kurt()

############### EDA ---> Fifth Moment Business #############

plt.boxplot(avocado.AveragePrice)
plt.boxplot(avocado.TotalVolume)
plt.boxplot(avocado.totava1)
plt.boxplot(avocado.totava2)
plt.boxplot(avocado.totava3)
plt.boxplot(avocado.TotalBags)
plt.boxplot(avocado.SmallBags)
plt.boxplot(avocado.LargeBags)
plt.boxplot(avocado.XLargeBags)


plt.hist(avocado.AveragePrice)
plt.hist(avocado.TotalVolume)
plt.hist(avocado.totava1)
plt.hist(avocado.totava2)
plt.hist(avocado.totava3)
plt.hist(avocado.TotalBags)
plt.hist(avocado.SmallBags)
plt.hist(avocado.LargeBags)
plt.hist(avocado.XLargeBags)

 
plt.scatter(x = avocado["AveragePrice"], y = avocado["TotalVolume"], color = 'green') 
plt.scatter(x = avocado["totava1"], y = avocado["totava2"], color = 'green') 
plt.scatter(x = avocado["totava3"], y = avocado["TotalBags"], color = 'green')
plt.scatter(x = avocado["SmallBags"], y = avocado["LargeBags"], color = 'green')


sns.jointplot(x=avocado['AveragePrice'], y=avocado['TotalVolume'])
sns.jointplot(x=avocado['totava1'], y=avocado['totava2'])
sns.jointplot(x=avocado['totava3'], y=avocado['TotalBags'])
sns.jointplot(x=avocado['SmallBags'], y=avocado['LargeBags'])

sns.countplot(avocado['AveragePrice'])
sns.countplot(avocado['TotalVolume'])
sns.countplot(avocado['totava1'])
sns.countplot(avocado['totava2'])
sns.countplot(avocado['totava3'])
sns.countplot(avocado['TotalBags'])
sns.countplot(avocado['SmallBags'])
sns.countplot(avocado['LargeBags'])

stats.probplot(avocado.AveragePrice, dist = "norm", plot = pylab),plt.show()
sns.pairplot(avocado.iloc[:, :10])

# Correlation matrix 
avocado.corr()

# preparing model considering all the variables 
import statsmodels.formula.api as smf
         
ml1 = smf.ols('AveragePrice ~ TotalVolume + totava1 + totava2 + totava3 + TotalBags + SmallBags + LargeBags', data = avocado).fit() 
ml1.summary()

# Checking whether data has any influential values 
# Influence Index Plots
import statsmodels.api as sm

sm.graphics.influence_plot(ml1)

# Check for Colinearity to decide to remove a variable using VIF
# Assumption: VIF > 10 = colinearity
# calculating VIF's values of independent variables
rsq_hp = smf.ols('AveragePrice ~ TotalVolume + totava1 + totava2 + totava3 + TotalBags + SmallBags + LargeBags', data = avocado).fit().rsquared  
vif_hp = 1/(1 - rsq_hp) 

rsq_wt = smf.ols('AveragePrice ~ TotalVolume + totava1 + totava2 + totava3 + TotalBags + SmallBags + LargeBags', data = avocado).fit().rsquared  
vif_wt = 1/(1 - rsq_wt)

rsq_vol = smf.ols('AveragePrice ~ TotalVolume + totava1 + totava2 + totava3 + TotalBags + SmallBags + LargeBags', data = avocado).fit().rsquared  
vif_vol = 1/(1 - rsq_vol) 

rsq_sp = smf.ols('AveragePrice ~ TotalVolume + totava1 + totava2 + totava3 + TotalBags + SmallBags + LargeBags', data = avocado).fit().rsquared  
vif_sp = 1/(1 - rsq_sp) 


# Final model
final_ml = smf.ols('AveragePrice ~ TotalVolume + totava1 + totava2 + totava3 + TotalBags + SmallBags + LargeBags', data = avocado).fit()
final_ml.summary() 

# Prediction
pred = final_ml.predict(avocado)

# Q-Q plot
res = final_ml.resid
sm.qqplot(res)
plt.show()

# Q-Q plot
stats.probplot(res, dist = "norm", plot = pylab)
plt.show()

# Residuals vs Fitted plot
sns.residplot(x = pred, y = avocado.AveragePrice, lowess = True)
plt.xlabel('Fitted')
plt.ylabel('Residual')
plt.title('Fitted vs Residual')
plt.show()

sm.graphics.influence_plot(final_ml)

### Splitting the data into train and test data 
from sklearn.model_selection import train_test_split
import numpy as np

avocado_train, avocado_test = train_test_split(avocado, test_size = 0.2)

# preparing the model on train data 
model_train = smf.ols("AveragePrice ~ TotalVolume + totava1 + totava2 + totava3 + TotalBags + SmallBags + LargeBags", data = avocado_train).fit()

# prediction on test data set 
test_pred = model_train.predict(avocado_test)

# test residual values 
test_resid = test_pred - avocado_test.AveragePrice
# RMSE value for test data 
test_rmse = np.sqrt(np.mean(test_resid * test_resid))
test_rmse


# train_data prediction
train_pred = model_train.predict(avocado_train)

# train residual values 
train_resid  = train_pred - avocado_train.AveragePrice
# RMSE value for train data 
train_rmse = np.sqrt(np.mean(train_resid * train_resid))
train_rmse
