import pandas as pd   
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import pylab

computer = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/20- Multiple Linear Regression/Assignments/Dataset/Computer_Data.csv")
computer.columns
computer.drop(["ID"], axis=1, inplace = True)


## Dummy Variables ###
computer = pd.get_dummies(computer, columns = ["cd"])
computer = pd.get_dummies(computer, columns = ["multi"])
computer = pd.get_dummies(computer, columns = ["premium"])


############### EDA ---> First Moment Business ##############

computer.mean()
computer.median()
computer.mode()

############### EDA ---> Second Moment Business ##############

computer.var()
computer.std()
    
############### EDA ---> Third Moment Business #############

computer.skew()

############### EDA ---> Fourth Moment Business #############

computer.kurt()

############### EDA ---> Fifth Moment Business #############

plt.boxplot(computer.price)
plt.boxplot(computer.speed)
plt.boxplot(computer.hd)
plt.boxplot(computer.ram)
plt.boxplot(computer.screen)


plt.hist(computer.price)
plt.hist(computer.speed)
plt.hist(computer.hd)
plt.hist(computer.ram)
plt.hist(computer.screen)


 
plt.scatter(x = computer["speed"], y = computer["hd"], color = 'green') 
plt.scatter(x = computer["ram"], y = computer["price"], color = 'green') 

sns.jointplot(x=computer['speed'], y=computer['hd'])
sns.countplot(computer['speed'])
stats.probplot(computer.price, dist = "norm", plot = pylab),plt.show()
sns.pairplot(computer.iloc[:, :6])

# Correlation matrix 
computer.corr()

# preparing model considering all the variables 
import statsmodels.formula.api as smf
         
ml1 = smf.ols('price ~ speed + hd + ram', data = computer).fit() 

# Summary
ml1.summary()

# Checking whether data has any influential values 
# Influence Index Plots
import statsmodels.api as sm

sm.graphics.influence_plot(ml1)

# Check for Colinearity to decide to remove a variable using VIF
# Assumption: VIF > 10 = colinearity
# calculating VIF's values of independent variables
rsq_hp = smf.ols('price ~ speed + hd + ram', data = computer).fit().rsquared  
vif_hp = 1/(1 - rsq_hp) 

rsq_wt = smf.ols('price ~ speed + hd + ram', data = computer).fit().rsquared  
vif_wt = 1/(1 - rsq_wt)

rsq_vol = smf.ols('price ~ speed + hd + ram', data = computer).fit().rsquared  
vif_vol = 1/(1 - rsq_vol) 

rsq_sp = smf.ols('price ~ speed + hd + ram', data = computer).fit().rsquared  
vif_sp = 1/(1 - rsq_sp) 


# Final model
final_ml = smf.ols('price ~ speed + hd + ram', data = computer).fit()
final_ml.summary() 

# Prediction
pred = final_ml.predict(computer)

# Q-Q plot
res = final_ml.resid
sm.qqplot(res)
plt.show()

# Q-Q plot
stats.probplot(res, dist = "norm", plot = pylab)
plt.show()

# Residuals vs Fitted plot
sns.residplot(x = pred, y = computer.price, lowess = True)
plt.xlabel('Fitted')
plt.ylabel('Residual')
plt.title('Fitted vs Residual')
plt.show()

sm.graphics.influence_plot(final_ml)

### Splitting the data into train and test data 
from sklearn.model_selection import train_test_split
import numpy as np

computer_train, computer_test = train_test_split(computer, test_size = 0.2)

# preparing the model on train data 
model_train = smf.ols("price ~ speed + hd + ram", data = computer_train).fit()

# prediction on test data set 
test_pred = model_train.predict(computer_test)

# test residual values 
test_resid = test_pred - computer_test.price
# RMSE value for test data 
test_rmse = np.sqrt(np.mean(test_resid * test_resid))
test_rmse


# train_data prediction
train_pred = model_train.predict(computer_train)

# train residual values 
train_resid  = train_pred - computer_train.price
# RMSE value for train data 
train_rmse = np.sqrt(np.mean(train_resid * train_resid))
train_rmse












