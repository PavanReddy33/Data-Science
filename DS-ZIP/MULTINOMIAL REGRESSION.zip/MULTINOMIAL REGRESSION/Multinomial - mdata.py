import pandas as pd
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

univ = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/22- Multinomial Regression/Assignment/Dataset/mdata.csv")
univ.head(10)
univ.describe()
univ.prog.value_counts()

# Removing unnecessary variables from data:

univ=univ.iloc[:,[5,2,3,4,10,6,7,8,9]]
# Renaming female column to gender:

univ.rename(columns={"female":"gender"},inplace=True)    

# converting categorical variables into numerical:

univ1=pd.get_dummies(univ.iloc[:,[1,3,4]],drop_first=True)
univ["ses"]=univ["ses"].map({'low':1,'middle':2,'high':3})
univ=pd.concat([univ,univ1],axis=1)

univ=pd.concat([univ,univ1],axis=1)
univ=univ.iloc[:,[0,2,5,6,7,8,9,10,11]]


# Checking and removing NA values if its there:

univ.isnull().sum()

# Scaling the data by MinMaxScaler:

from sklearn.preprocessing import MinMaxScaler
scale=MinMaxScaler()
univ.iloc[:,1:]=scale.fit_transform(univ.iloc[:,1:])
univ.columns


# Boxplot of independent variable distribution for each category of choice 
sns.boxplot(x = "prog", y = 'read', data = univ)
sns.boxplot(x = "prog", y = 'write', data = univ)
sns.boxplot(x = "prog", y = 'math', data = univ)
sns.boxplot(x = "prog", y = 'science', data = univ)
sns.boxplot(x = "prog", y = 'gender_male', data = univ)
sns.boxplot(x = "prog", y = 'ses', data = univ)
sns.boxplot(x = "prog", y = 'schtyp_public', data = univ)
sns.boxplot(x = "prog", y = 'honors_not enrolled', data = univ)

# Scatter plot for each categorical choice 
sns.stripplot(x = "prog", y = 'read', jitter = True, data = univ)
sns.stripplot(x = "prog", y = "write", jitter = True, data = univ)
sns.stripplot(x = "prog", y = "math", jitter = True, data = univ)
sns.stripplot(x = "prog", y = "science", jitter = True, data = univ)
sns.stripplot(x = "prog", y = "gender_male", jitter = True, data = univ)
sns.stripplot(x = "prog", y = "ses", jitter = True, data = univ)
sns.stripplot(x = "prog", y = "schtyp_public", jitter = True, data = univ)
sns.stripplot(x = "prog", y = 'honors_not enrolled', jitter = True, data = univ)

# Scatter plot between each possible pair of independent variable and also histogram for each independent variable 
sns.pairplot(univ) # Normal
sns.pairplot(univ, hue = "prog") # With showing the category of each car choice in the scatter plot

# Correlation values between each independent features
univ.corr()
pd.set_option('display.max_columns',None)
# Spliting the data by train_test_split function:

train, test = train_test_split(univ, test_size = 0.2)

# creating and applying multinomial model with ‘newton-cg’ solvers

model =LogisticRegression(multi_class = "multinomial", solver = "newton-cg",max_iter=100).fit(train.iloc[:,1:], train.iloc[:, 0])

# Test predictions

test_predict = model.predict(test.iloc[:, 1:]) 

# Test accuracy 

accuracy_score(test.iloc[:,0], test_predict)

# Train prediction 

train_predict = model.predict(train.iloc[:, 1:]) 

# Train accuracy 

accuracy_score(train.iloc[:,0], train_predict)
