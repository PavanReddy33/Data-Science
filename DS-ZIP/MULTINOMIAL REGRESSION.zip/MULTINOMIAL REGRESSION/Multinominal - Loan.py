import pandas as pd
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

loan = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/22- Multinomial Regression/Assignment/Dataset/loan.csv")
loan.head(10)
loan.describe()
loan.loan_status.value_counts()

# Removing unnecessary variables from data:

loan=loan.iloc[:,[2,3,4,5,6,7,13,16,24,25,30,31,32,33,34,36,37,38,39,40,41,42,43,44,46,49,51]]

# Removing unnecessary "months" and % characters from variables:
loan.info()
loan['term']=loan['term'].str.replace(r'\D','')
loan['int_rate']=loan['int_rate'].str.strip('%').astype(float)
loan['revol_util']=loan['revol_util'].str.strip('%').astype(float)

# Converting datatype of term variable to integer:

loan['term']=loan['term'].astype(int)

# Checking and removing NA values if its there:

loan.isnull().sum()
loan=loan.dropna(how='any',axis=0)

# Changing index of target variable loan_status to 0th position:

loan=loan.iloc[:,[7,0,1,2,3,4,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26]]

# Scaling the data by MinMaxScaler:

from sklearn.preprocessing import MinMaxScaler
scale=MinMaxScaler()
loan.iloc[:,1:]=scale.fit_transform(loan.iloc[:,1:])

# Boxplot of independent variable distribution for each category of choice 
sns.boxplot(x = "loan_status", y = "loan_amnt", data = loan)
sns.boxplot(x = "loan_status", y = "funded_amnt_inv", data = loan)
sns.boxplot(x = "loan_status", y = "int_rate", data = loan)
sns.boxplot(x = "loan_status", y = "annual_inc", data = loan)
sns.boxplot(x = "loan_status", y = "revol_bal", data = loan)
sns.boxplot(x = "loan_status", y = "total_acc", data = loan)
sns.boxplot(x = "loan_status", y = "out_prncp", data = loan)
sns.boxplot(x = "loan_status", y = "total_rec_int", data = loan)

# Scatter plot for each categorical choice of car
sns.stripplot(x = "loan_status", y = "loan_amnt", jitter = True, data = loan)
sns.stripplot(x = "loan_status", y = "funded_amnt_inv", jitter = True, data = loan)
sns.stripplot(x = "loan_status", y = "int_rate", jitter = True, data = loan)
sns.stripplot(x = "loan_status", y = "annual_inc", jitter = True, data = loan)
sns.stripplot(x = "loan_status", y = "revol_bal", jitter = True, data = loan)
sns.stripplot(x = "loan_status", y = "total_acc", jitter = True, data = loan)
sns.stripplot(x = "loan_status", y = "out_prncp", jitter = True, data = loan)
sns.stripplot(x = "loan_status", y = "total_rec_int", jitter = True, data = loan)

# Scatter plot between each possible pair of independent variable and also histogram for each independent variable 
sns.pairplot(loan) # Normal
sns.pairplot(loan, hue = "loan_status") # With showing the category of each car choice in the scatter plot

# Correlation values between each independent features
loan.corr()

# Spliting the data by train_test_split function:

train, test = train_test_split(loan, test_size = 0.2)

# creating and applying multinomial model with ‘newton-cg’ solvers
model = LogisticRegression(multi_class = "multinomial", solver = "newton-cg",max_iter=100).fit(train.iloc[:,1:], train.iloc[:, 0])

# Test predictions

test_predict = model.predict(test.iloc[:, 1:]) 

# Test accuracy 

accuracy_score(test.iloc[:,0], test_predict)

# Train predictions 

train_predict = model.predict(train.iloc[:, 1:]) 

# Train accuracy 

accuracy_score(train.iloc[:,0], train_predict)

