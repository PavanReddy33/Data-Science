import pandas as pd
import numpy as np

glass = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\KNN\Datasets_KNN\glass.csv")

glass.describe()
glass.isna().sum()
glass.var()

glass.duplicated().sum()

glass.info() # no categorical columns

# Normalization function 
def norm_func(i):
    x = (i-i.min())	/ (i.max()-i.min())
    return (x)


X = norm_func(glass.iloc[:,0:9]) #Predictors with normalized values
X.describe()

Y = glass['Type'] # Target 

glass['Type'].value_counts()

from sklearn.model_selection import train_test_split

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.20, stratify= Type,random_state=1, stratify=Y)

from sklearn.neighbors import KNeighborsClassifier



# creating empty list variable 
acc = []

# running KNN algorithm for 3 to 50 nearest neighbours(odd numbers) and 
# storing the accuracy values

for i in range(3,50,2):
    neigh = KNeighborsClassifier(n_neighbors=i)
    neigh.fit(X_train, Y_train)
    train_acc = np.mean(neigh.predict(X_train) == Y_train)
    test_acc = np.mean(neigh.predict(X_test) == Y_test)
    acc.append([train_acc, test_acc])


import matplotlib.pyplot as plt # library to do visualizations 

# train accuracy plot 
plt.plot(np.arange(3,50,2),[i[0] for i in acc],"ro-")

# test accuracy plot
plt.plot(np.arange(3,50,2),[i[1] for i in acc],"bo-")




knn = KNeighborsClassifier(n_neighbors = 9)
model=knn.fit(X_train, Y_train)

pred = model.predict(X_test)
pred


# Evaluate the model
from sklearn.metrics import accuracy_score
print(accuracy_score(Y_test, pred))
pd.crosstab(Y_test, pred, rownames = ['Actual'], colnames= ['Predictions']) 


# error on train data
pred_train = knn.predict(X_train)
print(accuracy_score(Y_train, pred_train))
pd.crosstab(Y_train, pred_train, rownames=['Actual'], colnames = ['Predictions']) 













