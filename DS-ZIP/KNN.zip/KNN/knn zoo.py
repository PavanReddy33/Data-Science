import pandas as pd
import numpy as np

zoo = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\KNN\Datasets_KNN\Zoo.csv")

zoo.info()

zoo.describe()

zoo.isna().sum()


# splitting the data

X = zoo.iloc[:,1:17]  #Predictors 
Y = zoo['type'] # Target 

# train and test data
from sklearn.model_selection import train_test_split

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.2)


# KNN package
from sklearn.neighbors import KNeighborsClassifier


acc = []

# running KNN algorithm for 3 to 50 nearest neighbours(odd numbers) and 
# storing the accuracy values

for i in range(3,50,2):
    neigh = KNeighborsClassifier(n_neighbors=i)
    neigh.fit(X_train, Y_train)
    train_acc = np.mean(neigh.predict(X_train) == Y_train)
    test_acc = np.mean(neigh.predict(X_test) == Y_test)
    acc.append([train_acc, test_acc])


import matplotlib.pyplot as plt # library to do visualizations 

# train accuracy plot 
plt.plot(np.arange(3,50,2),[i[0] for i in acc],"ro-")

# test accuracy plot
plt.plot(np.arange(3,50,2),[i[1] for i in acc],"bo-")





knn = KNeighborsClassifier(n_neighbors = 5)
knn.fit(X_train, Y_train)

pred = knn.predict(X_test)
pred


# Evaluate the model
from sklearn.metrics import accuracy_score
print(accuracy_score(Y_test, pred))
pd.crosstab(Y_test, pred, rownames = ['Actual'], colnames= ['Predictions']) 


# error on train data
pred_train = knn.predict(X_train)
print(accuracy_score(Y_train, pred_train))
pd.crosstab(Y_train, pred_train, rownames=['Actual'], colnames = ['Predictions']) 



