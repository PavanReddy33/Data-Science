import pandas as pd

# import Dataset 
movie = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\RECOMMENDATION ENGINE\Datasets_Recommendation Engine\Entertainment.csv")
movie.shape # shape
movie.columns
movie.Category # genre columns

from sklearn.feature_extraction.text import TfidfVectorizer #term frequencey- inverse document frequncy is a numerical statistic that is intended to reflect how important a word is to document in a collecion or corpus


#Creating a Tfidf Vectorizer to remove all stop words
tfidf = TfidfVectorizer(stop_words = "english")    # taking stop words from tfid vectorizer 

# replacing the NaN values in overview column with empty string
movie.isnull().sum() 

movie.duplicated().sum()
# Preparing the Tfidf matrix by fitting and transforming
tfidf_matrix = tfidf.fit_transform(movie.Category)   #Transform a count matrix to a normalized tf or tf-idf representation
tfidf_matrix




from sklearn.metrics.pairwise import linear_kernel

# Computing the cosine similarity on Tfidf matrix
cosine_sim_matrix = linear_kernel(tfidf_matrix, tfidf_matrix)

# creating a mapping of movie name to index number 
movie_index = pd.Series(movie.index, index = movie['Titles'])

movie_id = movie_index["Toy Story (1995)"]
movie_id

def get_recommendations(Titles, topN):    
    # topN = 10
    # Getting the movie index using its title 
    movie_id = movie_index[Titles]
    
    # Getting the pair wise similarity score for all the movie's with that 
    # movie
    cosine_scores = list(enumerate(cosine_sim_matrix[movie_id]))
    
    # Sorting the cosine_similarity scores based on scores 
    cosine_scores = sorted(cosine_scores, key=lambda x:x[1], reverse = True)
    
    # Get the scores of top N most similar movies 
    cosine_scores_N = cosine_scores[0: topN+1]
    
    # Getting the movie index 
    movie_idx  =  [i[0] for i in cosine_scores_N]
    movie_scores =  [i[1] for i in cosine_scores_N]
    
    # Similar movies and scores
    movie_similar_show = pd.DataFrame(columns=["Titles", "Score"])
    movie_similar_show["Titles"] = movie.loc[movie_idx, "Titles"]
    movie_similar_show["Score"] = movie_scores
    movie_similar_show.reset_index(inplace = True)  
    # movie_similar_show.drop(["index"], axis=1, inplace=True)
    print (movie_similar_show)
    # return (movie_similar_show)


get_recommendations("Heat (1995)", topN = 10)
movie_index["Heat (1995)"]
























