import pandas as pd

# import Dataset 
game = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\RECOMMENDATION ENGINE\Datasets_Recommendation Engine\game.csv")
game.shape # shape
game.columns

from sklearn.feature_extraction.text import TfidfVectorizer #term frequencey- inverse document frequncy is a numerical statistic that is intended to reflect how important a word is to document in a collecion or corpus


#Creating a Tfidf Vectorizer to remove all stop words
tfidf = TfidfVectorizer(stop_words = "english")    # taking stop words from tfid vectorizer 

# replacing the NaN values in overview column with empty string
game.isnull().sum() 

game['game'].duplicated().sum()

game.duplicated().sum()

# Preparing the Tfidf matrix by fitting and transforming
tfidf_matrix = tfidf.fit_transform(game.game)   #Transform a count matrix to a normalized tf or tf-idf representation
tfidf_matrix




from sklearn.metrics.pairwise import linear_kernel

# Computing the cosine similarity on Tfidf matrix
cosine_sim_matrix = linear_kernel(tfidf_matrix, tfidf_matrix)

# creating a mapping of game name to index number 
game_index = pd.Series(game.index, index = game['game']).drop_duplicates()

game_id = game_index["SoulCalibur"]
game_id


def get_recommendations(Name,topN):    
    my_game_id = game_index[Name]
    cosine_scores = list(enumerate(cosine_sim_matrix[my_game_id]))
    cosine_scores = sorted(cosine_scores, key=lambda x:x[1], reverse = True)
    cosine_scores_N = cosine_scores[0: topN+1]
    my_game_idx  =  [i[0] for i in cosine_scores_N]
    my_game_scores =  [i[1] for i in cosine_scores_N]
    my_game_similar_show = pd.DataFrame(columns=["game", "Score"])
    my_game_similar_show["game"] = game.loc[my_game_idx, "game"]
    my_game_similar_show["Score"] = my_game_scores
    my_game_similar_show.reset_index(inplace = True)  
    print (my_game_similar_show)




get_recommendations("The Legend of Zelda: Ocarina of Time", topN = 10)
game_index["The Legend of Zelda: Ocarina of Time"]






















