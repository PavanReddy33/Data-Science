import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf
import seaborn as sns

# loading the data
life = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/24- Lasso Ridge Regression/Assignment/Dataset/Life_expectencey_LR.csv",encoding='unicode_escape')
life=life.iloc[:,1:]
life.isnull().sum()

# for some variable we will impute NA using Mean and Meadian imputation by Simple Imputer 
from sklearn.impute import SimpleImputer

# Median imputation for discrete data - hepetitisb,population,g.d.p
median_imputer = SimpleImputer(missing_values=np.nan, strategy='median')
life["Hepatitis_B"] = pd.DataFrame(median_imputer.fit_transform(life[["Hepatitis_B"]]))
life["Population"] = pd.DataFrame(median_imputer.fit_transform(life[["Population"]]))
life["GDP"] = pd.DataFrame(median_imputer.fit_transform(life[["GDP"]]))


# Mean imputation for continuous data - alcohol,income_composition,total-expenditure,schooling
mean_imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
life["Alcohol"] = pd.DataFrame(mean_imputer.fit_transform(life[["Alcohol"]]))
life["Income_composition"] = pd.DataFrame(mean_imputer.fit_transform(life[["Income_composition"]]))
life["Total_expenditure"] = pd.DataFrame(mean_imputer.fit_transform(life[["Total_expenditure"]]))
life["Schooling"] = pd.DataFrame(mean_imputer.fit_transform(life[["Schooling"]]))

life.isnull().sum()

# Now we have left with 160 NA values.We will remove these from our dataset.
life=life.dropna()      # Now we have a clean data

# creating dummy variable for status column:
life=pd.get_dummies(life,columns=['Status'],drop_first=True)

# Changing target variable index to 1st position:
life=life.iloc[:,[1,0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]]
# Correlation matrix 
life.corr()

# EDA
life.describe()

# Sctter plot and histogram between variables
sns.pairplot(life) 

# Preparing the model on train data 
model_train = smf.ols("Life_expectancy~Year+Adult_Mortality+infant_deaths+Alcohol+percentage_expenditure+Hepatitis_B+Measles+BMI+under_five_deaths+Polio+Total_expenditure+Diphtheria+HIV_AIDS+GDP+Population+thinness+thinness_yr+Income_composition+Schooling+Status_Developing", data = life).fit()
model_train.summary()

# Prediction
pred = model_train.predict(life)
# Error
resid  = pred - life.Life_expectancy
# RMSE value for data 
rmse = np.sqrt(np.mean(resid * resid))
rmse

# To overcome the issues, LASSO and RIDGE regression are used
################
###LASSO MODEL###
from sklearn.linear_model import Lasso

lasso = Lasso(alpha = 0.13, normalize = True)

lasso.fit(life.iloc[:, 1:], life.Life_expectancy)

# Coefficient values for all independent variables#
lasso.coef_
lasso.intercept_

plt.bar(height = pd.Series(lasso.coef_), x = pd.Series(life.columns[1:]))

lasso.alpha

pred_lasso = lasso.predict(life.iloc[:, 1:])

# Adjusted r-square
lasso.score(life.iloc[:, 1:], life.Life_expectancy)

# RMSE
np.sqrt(np.mean((pred_lasso - life.Life_expectancy)**2))


### RIDGE REGRESSION ###
from sklearn.linear_model import Ridge

rm = Ridge(alpha = 0.4, normalize = True)

rm.fit(life.iloc[:, 1:], life.Life_expectancy)

# Coefficients values for all the independent vairbales
rm.coef_
rm.intercept_

plt.bar(height = pd.Series(rm.coef_), x = pd.Series(life.columns[1:]))

rm.alpha

pred_rm = rm.predict(life.iloc[:, 1:])

# Adjusted r-square
rm.score(life.iloc[:, 1:], life.Life_expectancy)

# RMSE
np.sqrt(np.mean((pred_rm - life.Life_expectancy)**2))


### ELASTIC NET REGRESSION ###
from sklearn.linear_model import ElasticNet

enet = ElasticNet(alpha = 0.4)

enet.fit(life.iloc[:, 1:], life.Life_expectancy) 

# Coefficients values for all the independent vairbales
enet.coef_
enet.intercept_

plt.bar(height = pd.Series(enet.coef_), x = pd.Series(life.columns[1:]))

enet.alpha

pred_enet = enet.predict(life.iloc[:, 1:])

# Adjusted r-square
enet.score(life.iloc[:, 1:], life.Life_expectancy)

# RMSE
np.sqrt(np.mean((pred_enet - life.Life_expectancy)**2))


####################

# Lasso Regression
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import Lasso

lasso = Lasso()

parameters = {'alpha': [1e-15, 1e-10, 1e-8, 1e-4, 1e-3, 1e-2, 1, 5 ,10, 20]}

lasso_reg = GridSearchCV(lasso, parameters, scoring = 'r2', cv = 5)
lasso_reg.fit(life.iloc[:, 1:], life.Life_expectancy)


lasso_reg.best_params_
lasso_reg.best_score_

lasso_pred = lasso_reg.predict(life.iloc[:, 1:])

# Adjusted r-square#
lasso_reg.score(life.iloc[:, 1:], life.Life_expectancy)

# RMSE
np.sqrt(np.mean((lasso_pred - life.Life_expectancy)**2))



# Ridge Regression
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import Ridge

ridge = Ridge()

parameters = {'alpha': [1e-15, 1e-10, 1e-8, 1e-4, 1e-3, 1e-2, 1, 5 ,10, 20]}

ridge_reg = GridSearchCV(ridge, parameters, scoring = 'r2', cv = 5)
ridge_reg.fit(life.iloc[:, 1:], life.Life_expectancy)

ridge_reg.best_params_
ridge_reg.best_score_

ridge_pred = ridge_reg.predict(life.iloc[:, 1:])

# Adjusted r-square#
ridge_reg.score(life.iloc[:, 1:], life.Life_expectancy)

# RMSE
np.sqrt(np.mean((ridge_pred - life.Life_expectancy)**2))



# ElasticNet Regression
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import ElasticNet

enet = ElasticNet()

parameters = {'alpha': [1e-15, 1e-10, 1e-8, 1e-4, 1e-3, 1e-2, 1, 5 ,10, 20]}

enet_reg = GridSearchCV(enet, parameters, scoring = 'neg_mean_squared_error', cv = 5)
enet_reg.fit(life.iloc[:, 1:], life.Life_expectancy)

enet_reg.best_params_
enet_reg.best_score_

enet_pred = enet_reg.predict(life.iloc[:, 1:])

# Adjusted r-square
enet_reg.score(life.iloc[:, 1:], life.Life_expectancy)

# RMSE
np.sqrt(np.mean((enet_pred - life.Life_expectancy)**2))
