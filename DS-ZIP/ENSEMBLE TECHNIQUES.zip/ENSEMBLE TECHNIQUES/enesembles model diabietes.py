import pandas as pd

df = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\ENSEMBLE TECHNIQUES\Datasets_ET\Diabeted_Ensemble.csv")

# Dummy variables
df.head()
df.info()
df.columns
df.isna().sum()
df.duplicated().sum()

df.describe()

import matplotlib.pyplot as plt

plt.hist(df[" Class variable"])

# Input and Output Split
predictors = df.loc[:, df.columns!=" Class variable"]
type(predictors)

target = df[" Class variable"]
type(target)


# Train Test partition of the data
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(predictors, target, test_size = 0.18, random_state=0)


#######BAGGING######



from sklearn import tree
clftree = tree.DecisionTreeClassifier()
from sklearn.ensemble import BaggingClassifier

#(n_samples=1000, n_features=20, n_informative=15, n_redundant=5, random_state=5)


bag_clf = BaggingClassifier(base_estimator = clftree,  n_estimators = 200,
                            bootstrap = True, n_jobs = 1, random_state = 50)

bag_clf.fit(x_train, y_train)

from sklearn.metrics import accuracy_score, confusion_matrix

# Evaluation on Testing Data
confusion_matrix(y_test, bag_clf.predict(x_test))
bagging_accuracy = accuracy_score(y_test, bag_clf.predict(x_test))
bagging_accuracy  #0.8201438848920863



# Evaluation on Training Data
confusion_matrix(y_train, bag_clf.predict(x_train))
accuracy_score(y_train, bag_clf.predict(x_train)) #1



##########BOOSTING######


from sklearn.ensemble import AdaBoostClassifier

ada_clf = AdaBoostClassifier(learning_rate = 0.15, n_estimators = 1000)

ada_clf.fit(x_train, y_train)
#.8051948051948052


# Evaluation on Testing Data
confusion_matrix(y_test, ada_clf.predict(x_test))
accuracy_score(y_test, ada_clf.predict(x_test))

# Evaluation on Training Data
accuracy_score(y_train, ada_clf.predict(x_train))
#.8469055374592834




########3radientBoostingClassifier#########

from sklearn.ensemble import GradientBoostingClassifier

boost_clf = GradientBoostingClassifier()

boost_clf.fit(x_train, y_train)

from sklearn.metrics import accuracy_score, confusion_matrix

confusion_matrix(y_test, boost_clf.predict(x_test))
accuracy_score(y_test, boost_clf.predict(x_test))
#0.8181818181818182


# Hyperparameters
boost_clf2 = GradientBoostingClassifier(learning_rate = 0.03, n_estimators = 500, max_depth = 3)
boost_clf2.fit(x_train, y_train)

# Evaluation on Testing Data
confusion_matrix(y_test, boost_clf2.predict(x_test))
accuracy_score(y_test, boost_clf2.predict(x_test))
#0.8246753246753247


# Evaluation on Training Data
accuracy_score(y_train, boost_clf2.predict(x_train))
#0.9495114006514658



########        VOTING    #############

# Import the required libraries
from sklearn import linear_model, svm, neighbors, naive_bayes
from sklearn.ensemble import VotingClassifier
from sklearn.metrics import accuracy_score


# Train Test partition of the data
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(predictors, target, test_size = 0.18, random_state=0)


# Instantiate the learners (classifiers)
learner_1 = neighbors.KNeighborsClassifier(n_neighbors=5)
learner_2 = linear_model.Perceptron(tol=1e-2, random_state=0)
learner_3 = svm.SVC(gamma=0.001)

# Instantiate the voting classifier
voting = VotingClassifier([('KNN', learner_1),
                           ('Prc', learner_2),
                           ('SVM', learner_3)])

# Fit classifier with the training data
voting.fit(x_train, y_train)

# Predict the most voted class
hard_predictions = voting.predict(x_test)

# Accuracy of hard voting
print('Hard Voting:', accuracy_score(y_test, hard_predictions))




# Soft Voting # 
# Instantiate the learners (classifiers)
learner_4 = neighbors.KNeighborsClassifier(n_neighbors = 5)
learner_5 = naive_bayes.GaussianNB()
learner_6 = svm.SVC(gamma = 0.001, probability = True)

# Instantiate the voting classifier
voting = VotingClassifier([('KNN', learner_4),
                           ('NB', learner_5),
                           ('SVM', learner_6)
                           ],
                            voting = 'soft')

# Fit classifier with the training data
voting.fit(x_train, y_train)
learner_4.fit(x_train, y_train)
learner_5.fit(x_train, y_train)
learner_6.fit(x_train, y_train)

# Predict the most probable class
soft_predictions = voting.predict(x_test)

# Get the base learner predictions
predictions_4 = learner_4.predict(x_test)
predictions_5 = learner_5.predict(x_test)
predictions_6 = learner_6.predict(x_test)

# Accuracies of base learners
print('L4:', accuracy_score(y_test, predictions_4))
print('L5:', accuracy_score(y_test, predictions_5))
print('L6:', accuracy_score(y_test, predictions_6))

# Accuracy of Soft voting
print('Soft Voting:', accuracy_score(y_test, soft_predictions))
