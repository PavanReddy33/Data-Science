import pandas as pd

df1 = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\ENSEMBLE TECHNIQUES\Datasets_ET\Tumor_Ensemble.csv")

df = df1.iloc[:,1:]
# Dummy variables
df.head()
df.info()
df.columns

df.describe()
df.isna().sum()

# Input and Output Split
predictors = df.loc[:, df.columns!="diagnosis"]
type(predictors)

target = df["diagnosis"]
type(target)


# Train Test partition of the data
from sklearn.model_selection import train_test_split

#######BAGGING######

from sklearn import tree
clftree = tree.DecisionTreeClassifier()
from sklearn.ensemble import BaggingClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

x_train, x_test, y_train, y_test = train_test_split(predictors, target, test_size = 0.18, random_state=0)


bag_clf = BaggingClassifier(base_estimator = clftree,  n_estimators = 100,bootstrap = True, n_jobs = 1, random_state = 50)
bag_clf.fit(x_train, y_train)

# Evaluation on Testing Data
confusion_matrix(y_test, bag_clf.predict(x_test))
bagging_accuracy = accuracy_score(y_test, bag_clf.predict(x_test))
bagging_accuracy  #0.941747572815534

# Evaluation on Training Data
confusion_matrix(y_train, bag_clf.predict(x_train))
accuracy_score(y_train, bag_clf.predict(x_train)) #1.0





##########BOOSTING######
from sklearn.ensemble import AdaBoostClassifier

ada_clf = AdaBoostClassifier(learning_rate = 0.03, n_estimators = 500)

ada_clf.fit(x_train, y_train)



# Evaluation on Testing Data
confusion_matrix(y_test, ada_clf.predict(x_test))
accuracy_score(y_test, ada_clf.predict(x_test))
#0.970873786407767

# Evaluation on Training Data
accuracy_score(y_train, ada_clf.predict(x_train))
#1.0







########        VOTING    #############

# Import the required libraries
from sklearn import linear_model, svm, neighbors, naive_bayes
from sklearn.ensemble import VotingClassifier
from sklearn.metrics import accuracy_score


# Train Test partition of the data
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(predictors, target, test_size = 0.18, random_state=0)


# Instantiate the learners (classifiers)
learner_1 = neighbors.KNeighborsClassifier(n_neighbors=5)
learner_2 = linear_model.Perceptron(tol=1e-2, random_state=0)
learner_3 = svm.SVC(gamma=0.001)

# Instantiate the voting classifier
voting = VotingClassifier([('KNN', learner_1),
                           ('Prc', learner_2),
                           ('SVM', learner_3)])

# Fit classifier with the training data
voting.fit(x_train, y_train)

# Predict the most voted class
hard_predictions = voting.predict(x_test)

# Accuracy of hard voting
print('Hard Voting:', accuracy_score(y_test, hard_predictions))
#0.9320388349514563



# Soft Voting # 
# Instantiate the learners (classifiers)
learner_4 = neighbors.KNeighborsClassifier(n_neighbors = 5)
learner_5 = naive_bayes.GaussianNB()
learner_6 = svm.SVC(gamma = 0.001, probability = True)

# Instantiate the voting classifier
voting = VotingClassifier([('KNN', learner_4),
                           ('NB', learner_5),
                           ('SVM', learner_6)
                           ],
                            voting = 'soft')

# Fit classifier with the training data
voting.fit(x_train, y_train)
learner_4.fit(x_train, y_train)
learner_5.fit(x_train, y_train)
learner_6.fit(x_train, y_train)

# Predict the most probable class
soft_predictions = voting.predict(x_test)

# Get the base learner predictions
predictions_4 = learner_4.predict(x_test)
predictions_5 = learner_5.predict(x_test)
predictions_6 = learner_6.predict(x_test)

# Accuracies of base learners
print('L4:', accuracy_score(y_test, predictions_4))#0.9320388349514563
print('L5:', accuracy_score(y_test, predictions_5))#0.912621359223301
print('L6:', accuracy_score(y_test, predictions_6))#0.941747572815534

# Accuracy of Soft voting
print('Soft Voting:', accuracy_score(y_test, soft_predictions))
#0.941747572815534


