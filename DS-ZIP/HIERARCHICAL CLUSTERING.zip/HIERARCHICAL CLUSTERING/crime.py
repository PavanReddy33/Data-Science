
import pandas as pd
import numpy as np


df = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\HIERARCHICAL CLUSTERING\Dataset_Assignment Clustering\crime_data.csv")   

df.info() # all the columns are in int

df.isna().sum() # no null values

### Identify duplicates records in the data
df.duplicated().sum()  # no duplicates

df.describe() # EDA

df.skew() # skewness
df.kurt() # kurtosis
df.var()

# plots

import matplotlib.pyplot as plt

plt.boxplot(df.Murder)
plt.boxplot(df.Assault)
plt.boxplot(df.UrbanPop)
plt.boxplot(df.Rape)


plt.bar(height = df.Rape, x = np.arange(1, 51, 1))
#We could see that Alaska and Nevada have the highest number of Rape cases.

# renaming the column
df.rename(columns={'Unnamed: 0':'States'},inplace=True)

# normalization

def norm_fun(i):
    x= (i - i.min()) / (i.max() - i.min())
    return (x)

norm = norm_fun(df.iloc[:,1:])

norm.describe()

from scipy.cluster.hierarchy import linkage
import scipy.cluster.hierarchy as sch 

z = linkage(norm, method = "complete", metric = "euclidean")


plt.figure(figsize=(15, 8));plt.title('Hierarchical Clustering Dendrogram');plt.xlabel('Index');plt.ylabel('Crime')
sch.dendrogram(z, 
    leaf_rotation = 0,  # rotates the x axis labels
    leaf_font_size = 7 # font size for the x axis labels
)
plt.show()


# Now applying AgglomerativeClustering choosing 5 as clusters from the above dendrogram
from sklearn.cluster import AgglomerativeClustering

h_complete = AgglomerativeClustering(n_clusters = 4, linkage = 'complete', affinity = "euclidean").fit(norm) 
h_complete.labels_

cluster_labels = pd.Series(h_complete.labels_)

df['crime_rate'] = cluster_labels # creating a new column and assigning it to new column 

#changed the data for easy understanding.
df["crime_rate"].replace({0:"very high", 1: "medium",2:"low", 3: "high"},inplace=(True))

df.iloc[:, 1:5].groupby(df.crime_rate).mean()
df.iloc[:, 1:5].groupby(df.crime_rate).var()


df.crime_rate.value_counts()
