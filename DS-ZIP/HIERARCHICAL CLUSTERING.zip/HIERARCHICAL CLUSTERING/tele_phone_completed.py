
import pandas as pd

df1 = pd.read_excel(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\HIERARCHICAL CLUSTERING\Dataset_Assignment Clustering\Telco_customer_churn.xlsx")   

df1.columns

# removing unwanted data
df = df1.drop(['Customer ID','Count','Quarter','Number of Referrals','Phone Service','Internet Service','Online Security','Online Backup','Streaming TV','Streaming Movies','Streaming Music','Paperless Billing','Payment Method'],axis=1)


df.info() 

df.isna().sum() # no null values

### Identify duplicates records in the data
df.duplicated().sum()  # no duplicates

df.describe() # EDA

df.skew() # skewness
df.kurt() # kurtosis
df.var()

# plots


import matplotlib.pyplot as plt
plt.hist(df['Offer'])
plt.hist(df['Referred a Friend'])
plt.hist(df['Internet Type'])
plt.hist(df['Device Protection Plan'])
plt.hist(df['Contract'])
plt.hist(df['Unlimited Data'])
plt.hist(df['Premium Tech Support'])


plt.boxplot(df['Total Revenue'])
plt.boxplot(df['Monthly Charge'])
plt.boxplot(df['Tenure in Months'])
plt.boxplot(df['Total Long Distance Charges'])

df.info()
# dummy variables

df_new_1 = pd.get_dummies(df, drop_first = True)



# normalization

def norm_fun(i):
    x= (i - i.min()) / (i.max() - i.min())
    return (x)



norm = norm_fun(df_new_1.iloc[:,:])
norm.info()

norm.describe()


from scipy.cluster.hierarchy import linkage
import scipy.cluster.hierarchy as sch 


z = linkage(norm, method = "complete", metric = "euclidean")



plt.figure(figsize=(60 , 16));plt.title('Hierarchical Clustering Dendrogram');plt.xlabel('Index');plt.ylabel('Crime')
sch.dendrogram(z, 
    leaf_rotation = 0,  # rotates the x axis labels
    leaf_font_size = 3 # font size for the x axis labels
)
plt.show()


# Now applying AgglomerativeClustering choosing 5 as clusters from the above dendrogram
from sklearn.cluster import AgglomerativeClustering


h_complete = AgglomerativeClustering(n_clusters =3, linkage = 'complete', affinity = "euclidean").fit(norm) 
h_complete.labels_

cluster_labels = pd.Series(h_complete.labels_)


df['curn_rate'] = cluster_labels # creating a new column and assigning it to new column 



summary1=df.iloc[:,].groupby(df.curn_rate).mean()
df.iloc[:,  ].groupby(df.curn_rate).var()


df.to_csv("crun_data.csv", encoding = "utf-8")















