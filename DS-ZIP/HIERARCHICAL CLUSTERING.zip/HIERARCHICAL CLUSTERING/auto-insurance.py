
import pandas as pd
import numpy as np


df1 = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\HIERARCHICAL CLUSTERING\Dataset_Assignment Clustering\AutoInsurance.csv")   
data_sumary=df1.describe()

df=df1.drop(['Customer','State','Response','Effective To Date','Gender','Location Code','Marital Status'],axis=1)


df.info() #float64(2), int64(6), object(9)
df.isna().sum() # no null values


### Identify duplicates records in the data
df.duplicated().sum()  # no duplicates

df.describe() # EDA

df.skew() # skewness
df.kurt() # kurtosis
df.var()

# plots

import matplotlib.pyplot as plt

plt.boxplot(df['Total Claim Amount'])
plt.boxplot(df['Number of Open Complaints'])
plt.boxplot(df['Income'])

plt.hist(df['Vehicle Size'])
plt.hist(df['Vehicle Class'])
plt.hist(df['Policy'])
plt.hist(df['Policy Type'])


#dummy variables
from sklearn.preprocessing import LabelEncoder
labelencoder=LabelEncoder()

df['Coverage'] = labelencoder.fit_transform(df['Coverage'])
df['Policy Type'] = labelencoder.fit_transform(df['Policy Type'])
df['Policy'] = labelencoder.fit_transform(df['Policy'])
df['Renew Offer Type'] = labelencoder.fit_transform(df['Renew Offer Type'])
df['Vehicle Class'] = labelencoder.fit_transform(df['Vehicle Class'])
df['Vehicle Size'] = labelencoder.fit_transform(df['Vehicle Size'])
df['Education'] = labelencoder.fit_transform(df['Education'])
df['EmploymentStatus'] = labelencoder.fit_transform(df['EmploymentStatus'])
df['Sales Channel'] = labelencoder.fit_transform(df['Sales Channel'])

df.info()



# normalization

def norm_fun(i):
    x= (i - i.min()) / (i.max() - i.min())
    return (x)

norm = norm_fun(df.iloc[:,:])

norm.describe()

from scipy.cluster.hierarchy import linkage
import scipy.cluster.hierarchy as sch 

z = linkage(norm, method = "ward", metric = "euclidean")


plt.figure(figsize=(50, 10));plt.title('Hierarchical Clustering Dendrogram');plt.xlabel('Index');plt.ylabel('Crime')
sch.dendrogram(z, 
    leaf_rotation = 0,  # rotates the x axis labels
    leaf_font_size = 7 # font size for the x axis labels
)
plt.show()


# Now applying AgglomerativeClustering choosing 5 as clusters from the above dendrogram
from sklearn.cluster import AgglomerativeClustering

h_complete = AgglomerativeClustering(n_clusters = 4, linkage = 'ward', affinity = "euclidean").fit(norm) 
h_complete.labels_

cluster_labels = pd.Series(h_complete.labels_)

df['claim_rate'] = cluster_labels # creating a new column and assigning it to new column 

#changed the data for easy understanding.
#df["crime_rate"].replace({0:"very high", 1: "medium",2:"low", 3: "high"},inplace=(True))

summary=df.iloc[:, :].groupby(df.claim_rate).mean()
df.iloc[:, 1:5].groupby(df.claim_rate).var()


df.crime_rate.value_counts()
