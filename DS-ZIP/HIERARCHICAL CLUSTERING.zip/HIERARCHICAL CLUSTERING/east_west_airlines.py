

import pandas as pd



#df = pd.read_excel(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\HIERARCHICAL CLUSTERING\Dataset_Assignment Clustering\EastWestAirlines.xlsx", sheet_name='data')   
df = pd.read_excel(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\HIERARCHICAL CLUSTERING\Dataset_Assignment Clustering\EastWestAirlines.xlsx", sheet_name='data')   


df.info() # all the columns are in int

df.isna().sum() # no null values

### Identify duplicates records in the data
df.duplicated().sum()  # no duplicates

df.describe() # EDA

df.skew() # skewness
df.kurt() # kurtosis


# plots

import matplotlib.pyplot as plt

plt.boxplot(df.Balance)
plt.hist(df.Bonus_miles)

df.drop(['ID#','Award?'],axis=1,inplace=True) #dropping these two columns as they don't hold any key info



# Converting miles data into numerical data with taking the average of the range

df["cc1_miles"].replace({1:2500, 2:7500 ,3:17500, 4: 32500,5:50000},inplace=(True))
df["cc2_miles"].replace({1:2500, 2:7500 ,3:17500, 4: 32500,5:50000},inplace=(True))
df["cc3_miles"].replace({1:2500, 2:7500 ,3:17500, 4: 32500,5:50000},inplace=(True))


# Standardization

from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

stand = scaler.fit_transform(df)

stand=pd.DataFrame(stand)

stand.describe()


# for creating dendrogram 
from scipy.cluster.hierarchy import linkage
import scipy.cluster.hierarchy as sch 

z = linkage(stand, method = "ward", metric = "euclidean")

# Dendrogram
plt.figure(figsize=(50, 16));plt.title('Hierarchical Clustering Dendrogram');plt.xlabel('Index');plt.ylabel('Distance')
sch.dendrogram(z, 
    leaf_rotation = 0,  # rotates the x axis labels
    leaf_font_size = 10 # font size for the x axis labels
)
plt.show()


# Now applying AgglomerativeClustering choosing 5 as clusters from the above dendrogram
from sklearn.cluster import AgglomerativeClustering

h_complete = AgglomerativeClustering(n_clusters = 3, linkage = 'ward', affinity = "euclidean").fit(stand) 
h_complete.labels_

cluster_labels = pd.Series(h_complete.labels_)

df['clust'] = cluster_labels # creating a new column and assigning it to new column 

df.count

# Aggregate mean of each cluster
summary=df.iloc[:, :].groupby(df.clust).mean()

plt.hist(df['clust'])
df.clust.value_counts()














