

import pandas as pd



#df = pd.read_excel(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\HIERARCHICAL CLUSTERING\Dataset_Assignment Clustering\EastWestAirlines.xlsx", sheet_name='data')   
df = pd.read_excel(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\HIERARCHICAL CLUSTERING\Dataset_Assignment Clustering\EastWestAirlines.xlsx", sheet_name='data')   

df1 = pd.read_excel(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\HIERARCHICAL CLUSTERING\Dataset_Assignment Clustering\EastWestAirlines.xlsx", sheet_name='data')   

df.info() # all the columns are in int

df.isna().sum() # no null values

### Identify duplicates records in the data
df.duplicated().sum()  # no duplicates

df.describe() # EDA

df.skew() # skewness
df.kurt() # kurtosis
df.var() # varinace

# plots

import matplotlib.pyplot as plt

plt.boxplot(df.Balance)
plt.hist(df.Bonus_miles)

df.drop(['ID#','Award?'],axis=1,inplace=True) #dropping these two columns as they don't hold any key info



# Converting miles data into numerical data with taking the average of the range

df["cc1_miles"].replace({1:2500, 2:7500 ,3:17500, 4: 32500,5:50000},inplace=(True))
df["cc2_miles"].replace({1:2500, 2:7500 ,3:17500, 4: 32500,5:50000},inplace=(True))
df["cc3_miles"].replace({1:2500, 2:7500 ,3:17500, 4: 32500,5:50000},inplace=(True))


# Standardization

from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

stand = scaler.fit_transform(df)

stand=pd.DataFrame(stand)

stand.describe()


from sklearn.cluster import	KMeans


###### scree plot or elbow curve ############
TWSS = []
k = list(range(2, 9))

for i in k:
    kmeans = KMeans(n_clusters = i)
    kmeans.fit(stand)
    TWSS.append(kmeans.inertia_)
    
TWSS
# Scree plot 
plt.plot(k, TWSS, 'ro-');plt.xlabel("No_of_Clusters");plt.ylabel("total_within_SS")

# Selecting 3 clusters from the above scree plot which is the optimum number of clusters 
model = KMeans(n_clusters = 3)
model.fit(stand)

model.labels_ # getting the labels of clusters assigned to each row 
mb = pd.Series(model.labels_)  # converting numpy array into pandas series object 
df['clust'] = mb # creating a  new column and assigning it to new column 

summary=df.iloc[:, :].groupby(df.clust).mean()

df['clust'].value_counts() # 72% of the data is in single cluster


df.to_csv("Kmeans_university.csv", encoding = "utf-8")

import os
os.getcwd()




