
import pandas as pd
import numpy as np


#df = pd.read_csv(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\K_MEANS CLUSTERING\Datasets_Kmeans\Insurance Dataset.csv")   
df = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\K_MEANS CLUSTERING\Datasets_Kmeans\Insurance Dataset.csv")   

df.info() # all the columns are in int

df.isna().sum() # no null values

### Identify duplicates records in the data
df.duplicated().sum()  # no duplicates

df.describe() # EDA

df.skew() # skewness
df.kurt() # kurtosis
df.var()

# plots

import matplotlib.pyplot as plt

plt.boxplot(df['Premiums Paid'])
plt.boxplot(df.Age)
plt.boxplot(df.Income)
plt.boxplot(df['Days to Renew'])
plt.boxplot(df['Claims made'])

plt.bar(height = df['Claims made'], x = np.arange(1, 101, 1))

#We could see that there are few users who have made huge claims

# normalization

def norm_fun(i):
    x= (i - i.min()) / (i.max() - i.min())
    return (x)

norm = norm_fun(df.iloc[:,:])

norm.describe()

from sklearn.cluster import	KMeans


###### scree plot or elbow curve ############
TWSS = []
k = list(range(2, 9))

for i in k:
    kmeans = KMeans(n_clusters = i)
    kmeans.fit(norm)
    TWSS.append(kmeans.inertia_)
    
TWSS
# Scree plot 
plt.plot(k, TWSS, 'ro-');plt.xlabel("No_of_Clusters");plt.ylabel("total_within_SS")

# Selecting 4 and clusters from the above scree plot which is the optimum number of clusters 

#model = KMeans(n_clusters = 3)
#model.fit(norm)

#model.labels_ # getting the labels of clusters assigned to each row 
#mb = pd.Series(model.labels_)  # converting numpy array into pandas series object 
#df['clust'] = mb # creating a  new column and assigning it to new column 

#summary_4=df.iloc[:, :].groupby(df.clust).mean()


### cluster = 3
model_3 = KMeans(n_clusters = 3)
model_3.fit(norm)

model_3.labels_ # getting the labels of clusters assigned to each row 
mb_3 = pd.Series(model_3.labels_)  # converting numpy array into pandas series object 
df['clust'] = mb_3 # creating a  new column and assigning it to new column 

summary__3=df.iloc[:, :].groupby(df.clust).mean()

# after comparing 3 and 4 number of cluster's, the data makes more sense whn cluster numbers are 3




df.to_csv("Kmeans_cliams.csv", encoding = "utf-8")

import os
os.getcwd()














