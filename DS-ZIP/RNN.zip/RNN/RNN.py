import pandas as pd
import numpy as np
from numpy import array
from keras.models import Sequential
from keras.layers import LSTM
from keras.layers import Dense
from keras.layers import Bidirectional

#split univariate sequence 
def split_sequence(sequence, n_steps):
 x,y = list(),list()
 for i in range(len(sequence)):#fine the end of this pattern 
 end_ix = i+ n_steps #check if we are beyond the sequence
 if end_ix>len(sequence)-1:
 break
    #gather input and output parts of the pattern 
seq_x, seq_y = sequence[i:end_ix], sequence[end_ix]
x.append(seq_x)
y.append(seq_y)
return array(x), array(y)

raw_seq = [110,125,133,146,158,172,187,196,210]
yhat = []

for i in range(0,10):
    L = len(raw_seq)

n_stpes = 3
x,y = split_sequence(raw_seq, n_stpes)
n_feature = 1    
x = x.reshape((x.shape[0], x.shape[1], n_feature))
model = Sequential()
model.add(Bidirectional(LSTM(50, activation='relu'),input_shape = (n_stpes, n_feature)))
model.add(Dense(1))
model.compile(optimizer='adam',loss='mse')
model.fit(x,y, epochs=200, verbose=0)
x_input = array([raw_seq[L-3],raw_seq[L-2], raw_seq[L-1]])
x_input = x_input.reshape((1, n_stpes, n_feature))
yhat = model.predict(x_input, verbose=0)
yhat = np.array(yhat).astype("int")
new = yhat
raw_seq.extend(new[0])
print("concatenated list using list.extend():" + str(raw_seq))
