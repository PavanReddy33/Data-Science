import pandas as pd
from sklearn.preprocessing import LabelEncoder


data = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\DECISION TREE\Datasets_DTRF\Company_Data.csv")

data.info()
data.isna().sum()
data.duplicated().sum()

data.describe()

import matplotlib.pyplot as plt

plt.boxplot(data.Sales)

labelencoder = LabelEncoder()


data['Urban'] = labelencoder.fit_transform(data['Urban'])
data['US'] = labelencoder.fit_transform(data['US'])


def norm_func(i):
	x = (i-i.min())	/(i.max()-i.min())
	return(x)

data_norm = norm_func(data)


predictors = data_norm.iloc[:,1:]
target = data_norm.iloc[:,0]

type(predictors)
type(target)


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(predictors, target, test_size = 0.2, random_state=0)



# Train the Regression DT
from sklearn import tree
regtree = tree.DecisionTreeRegressor(max_depth = 3)
regtree.fit(x_train, y_train)

# Prediction
test_pred = regtree.predict(x_test)
train_pred = regtree.predict(x_train)

# Measuring accuracy
from sklearn.metrics import mean_squared_error, r2_score

# Error on test dataset
mean_squared_error(y_test, test_pred)
r2_score(y_test, test_pred)

# Error on train dataset
mean_squared_error(y_train, train_pred)
r2_score(y_train, train_pred)




regtree2 = tree.DecisionTreeRegressor(min_samples_split = 3)
regtree2.fit(x_train, y_train)

# Prediction
test_pred2 = regtree2.predict(x_test)
train_pred2 = regtree2.predict(x_train)

# Error on test dataset
mean_squared_error(y_test, test_pred2)
r2_score(y_test, test_pred2)

# Error on train dataset
mean_squared_error(y_train, train_pred2)
r2_score(y_train, train_pred2)

###########
## Minimum observations at the leaf node approach
regtree3 = tree.DecisionTreeRegressor(min_samples_leaf = 3)
regtree3.fit(x_train, y_train)

# Prediction
test_pred3 = regtree3.predict(x_test)
train_pred3 = regtree3.predict(x_train)

# measure of error on test dataset
mean_squared_error(y_test, test_pred3)
r2_score(y_test, test_pred3)

# measure of error on train dataset
mean_squared_error(y_train, train_pred3)
r2_score(y_train, train_pred3)
