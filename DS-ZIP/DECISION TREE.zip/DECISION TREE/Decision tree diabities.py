import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder


data = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\DECISION TREE\Datasets_DTRF\Diabetes.csv")


labelencoder = LabelEncoder()


data.info()
data.describe()
data.columns
data[' Class variable'] = labelencoder.fit_transform(data[' Class variable'])



def norm_func(i):
	x = (i-i.min())	/(i.max()-i.min())
	return(x)



colnames = list(data.columns)

predictors = colnames[:8]
target = colnames[8]

# Splitting data into training and testing data set
from sklearn.model_selection import train_test_split
train, test = train_test_split(data, test_size = 0.30)

from sklearn.tree import DecisionTreeClassifier as DT


model = DT(criterion = 'entropy')
model.fit(train[predictors], train[target])


# Prediction on Test Data
preds = model.predict(test[predictors])
pd.crosstab(test[target], preds, rownames=['Actual'], colnames=['Predictions'])

np.mean(preds == test[target]) # Test Data Accuracy 

# Prediction on Train Data
preds = model.predict(train[predictors])
pd.crosstab(train[target], preds, rownames = ['Actual'], colnames = ['Predictions'])

np.mean(preds == train[target]) # Train Data Accuracy
