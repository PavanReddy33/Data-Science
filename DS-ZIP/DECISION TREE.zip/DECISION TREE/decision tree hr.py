import pandas as pd


data = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\DECISION TREE\Datasets_DTRF\HR_DT.csv")


data.info()
data.isna().sum()


# n-1 dummy variables will be created for n categories
data = pd.get_dummies(data, columns = ["Position of the employee"], drop_first = True)



def norm_func(i):
	x = (i-i.min())	/(i.max()-i.min())
	return(x)


df_norm = norm_func(data)

df_norm.columns

predictors = df_norm.loc[:, df_norm.columns!=" monthly income of employee"]
type(predictors)

target = df_norm.iloc[:,1]
type(target)



# Train Test partition of the data
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(predictors, target, test_size = 0.2, random_state=0)

# Train the Regression DT
from sklearn import tree
regtree = tree.DecisionTreeRegressor(max_depth = 3)
regtree.fit(x_train, y_train)

# Prediction
test_pred = regtree.predict(x_test)
train_pred = regtree.predict(x_train)

# Measuring accuracy
from sklearn.metrics import mean_squared_error, r2_score

# Error on test dataset
mean_squared_error(y_test, test_pred)
r2_score(y_test, test_pred)


# Error on train dataset
mean_squared_error(y_train, train_pred)
r2_score(y_train, train_pred)


