import pandas as pd
import numpy as np

data = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\DECISION TREE\Datasets_DTRF\Fraud_check.csv")

data.info()
data.describe()
data.isna().sum()

data['Risk_level'] = np.where(data['Taxable.Income'] <= 30000, 'Risky', 'Good')

data.head()


data = pd.get_dummies(data, columns=['Undergrad','Marital.Status','Urban','Risk_level'],drop_first=True)

predictors = data.iloc[:,0:7]
type(predictors)

target = data.iloc[:,7:]
type(target)



# Train Test partition of the data
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(predictors, target, test_size = 0.2, random_state=0)

# Train the Regression DT
from sklearn import tree
regtree = tree.DecisionTreeRegressor(max_depth = 3)
regtree.fit(x_train, y_train)

# Prediction
test_pred = regtree.predict(x_test)
train_pred = regtree.predict(x_train)

# Measuring accuracy
from sklearn.metrics import mean_squared_error, r2_score

# Error on test dataset
mean_squared_error(y_test, test_pred)
r2_score(y_test, test_pred)


# Error on train dataset
mean_squared_error(y_train, train_pred)
r2_score(y_train, train_pred)











from sklearn.model_selection import train_test_split
train, test = train_test_split(data, test_size = 0.3)

from sklearn.tree import DecisionTreeClassifier as DT

help(DT)
model = DT(criterion = 'entropy')
model.fit(train[predictors], train[target])


# Prediction on Test Data
preds = model.predict(test[predictors])
pd.crosstab(test[target], preds, rownames=['Actual'], colnames=['Predictions'])

np.mean(preds == test[target]) # Test Data Accuracy 

# Prediction on Train Data
preds = model.predict(train[predictors])
pd.crosstab(train[target], preds, rownames = ['Actual'], colnames = ['Predictions'])

np.mean(preds == train[target]) # Train Data Accuracy
