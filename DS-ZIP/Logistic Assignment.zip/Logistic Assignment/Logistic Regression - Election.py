import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.formula.api as sm
from sklearn.model_selection import train_test_split # train and test 
from sklearn import metrics
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import classification_report

#Importing Data
election = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/21- Logistic Regression/Assignment/Dataset/election_data.csv", sep = ",")
election.columns

# Removing election id variable as its not necessary for prediction:
c1 = election.drop('Election-id', axis = 1)
c1.head(11)
c1.describe()
c1.isna().sum()
c1.dtypes
c1.columns

# for Mean and Mode imputation we can use Simple Imputer 
from sklearn.impute import SimpleImputer

# Mean Imputer 
mean_imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
c1['Year'] = pd.DataFrame(mean_imputer.fit_transform(c1[['Year']]))
c1['AmountSpent'] = pd.DataFrame(mean_imputer.fit_transform(c1[['AmountSpent']]))
c1['Year'].isnull().sum()
c1['AmountSpent'].isnull().sum()  # all 2 records replaced by mean 


# Mode Imputer
mode_imputer = SimpleImputer(missing_values=np.nan, strategy='most_frequent')
c1['Result'] = pd.DataFrame(mode_imputer.fit_transform(c1[['Result']]))
c1['PopularityRank'] = pd.DataFrame(mode_imputer.fit_transform(c1[['PopularityRank']]))

c1['Result'].isnull().sum()
c1['PopularityRank'].isnull().sum()   # all 2 records replaced by mode
c1.isnull().sum()  

c1.rename(columns={'AmountSpent':"Amountspend",'PopularityRank':"PopularityRank"},inplace=True)
c1["PopularityRank"]=pd.cut(c1.PopularityRank,bins=2,labels=(0,1))   

c1.columns
# Model building 
# import statsmodels.formula.api as sm
logit_model = sm.logit('Result ~ Year + Amountspend + PopularityRank', data = c1).fit()

#summary
logit_model.summary2() # for AIC
logit_model.summary()

pred = logit_model.predict(c1.iloc[ :, 1: ])

# from sklearn import metrics
fpr, tpr, thresholds = roc_curve(c1.Result, pred)
optimal_idx = np.argmax(tpr - fpr)
optimal_threshold = thresholds[optimal_idx]
optimal_threshold

import pylab as pl

i = np.arange(len(tpr))
roc = pd.DataFrame({'fpr' : pd.Series(fpr, index=i),'tpr' : pd.Series(tpr, index = i), '1-fpr' : pd.Series(1-fpr, index = i), 'tf' : pd.Series(tpr - (1-fpr), index = i), 'thresholds' : pd.Series(thresholds, index = i)})
roc.iloc[(roc.tf-0).abs().argsort()[:1]]

# Plot tpr vs 1-fpr
fig, ax = pl.subplots()
pl.plot(roc['tpr'], color = 'red')
pl.plot(roc['1-fpr'], color = 'blue')
pl.xlabel('1-False Positive Rate')
pl.ylabel('True Positive Rate')
pl.title('Receiver operating characteristic')
ax.set_xticklabels([])

roc_auc = auc(fpr, tpr)
print("Area under the ROC curve : %f" % roc_auc)

# filling all the cells with zeroes
c1["pred"] = np.zeros(11)
# taking threshold value and above the prob value will be treated as correct value 
c1.loc[pred>optimal_threshold, "pred"] = 1
# classification report
classification = classification_report(c1["pred"], c1["Result"])
classification


### Splitting the data into train and test data 
# from sklearn.model_selection import train_test_split
train_data, test_data = train_test_split(c1, test_size = 0.4) # 30% test data

# Model building 
# import statsmodels.formula.api as sm
model = sm.logit('Result~Year+Amountspend+PopularityRank', data = train_data).fit()

#summary
model.summary2() # for AIC
model.summary()

# Prediction on Test data set
test_pred = logit_model.predict(test_data)

# Creating new column for storing predicted class of Attorney
# filling all the cells with zeroes
test_data["test_pred"] = np.zeros(5)

# taking threshold value as 'optimal_threshold' and above the thresoldprob value will be treated as 1 
test_data.loc[test_pred>optimal_threshold, "test_pred"] = 1

# confusion matrix 
confusion_matrix = pd.crosstab(test_data.test_pred, test_data['Result'])
confusion_matrix

accuracy_test = (1 + 3)/(5) 
accuracy_test

# classification report
classification_test = classification_report(test_data["test_pred"], test_data["Result"])
classification_test

#ROC CURVE AND AUC
fpr, tpr, threshold = metrics.roc_curve(test_data["Result"], test_pred)

#PLOT OF ROC
plt.plot(fpr, tpr);plt.xlabel("False positive rate");plt.ylabel("True positive rate")

roc_auc_test = metrics.auc(fpr, tpr)
roc_auc_test


# prediction on train data
train_pred = model.predict(train_data.iloc[ :, 1: ])

# Creating new column 
# filling all the cells with zeroes
train_data["train_pred"] = np.zeros(6)

# taking threshold value and above the prob value will be treated as correct value 
train_data.loc[train_pred>optimal_threshold, "train_pred"] = 1

# confusion matrix
confusion_matrx = pd.crosstab(train_data.train_pred, train_data['Result'])
confusion_matrx

accuracy_train = (3 + 2)/(6)
print(accuracy_train)

