import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


sns.set_style('whitegrid')

# Loading and Reading the advertising dataset- 'Advertising data.csv'


advertise = pd.read_csv('C:/Users/Ultimate/Desktop/Data Science/Assignments/21- Logistic Regression/Assignment/Dataset/advertising.csv')

# Checking the head of ads_data
advertise.head()

# To get the information of the ads_data
advertise.info()

# We use a describe method on the ads_data to get the statistical information about the numerical columns
advertise.describe()

# Exploratory Data Analysis

# Let's use seaborn to explore the data!

# Creating a histogram of the Age column
advertise['Age'].plot.hist(30)
plt.xlabel('Age')

# Creating a jointplot of Area Income versus Age 
sns.jointplot(x='Age', y='Area_Income', data=advertise)

# Creating a jointplot showing kde distributions of Daily Time Spent on Site versus Age

sns.jointplot(x='Age', y='Daily_Time_ Spent _on_Site', data=advertise, kind='kde', color='lavender')

# Creating a jointplot of Daily Time Spent on Site versus Daily Internet Usage

sns.jointplot(x='Daily_Time_ Spent _on_Site', y='Daily Internet Usage', data=advertise, color='brown')

# We can explore a little more by doing jointplot for every single numerical column by using pairplot on the data
# Creating a pairplot with hue defined by Clicked on Ad column
sns.pairplot(advertise, hue='Clicked_on_Ad', palette='bwr')

# Splitting the data into train & test datasets
# Now let's split the data into a training set and a testing set. We will train our model on the training set and then use the test set to evaluate the model. We use SkiKit learn to do this.

# Scikit Learn: A Scikit learn package is used here. It is the most popular machine learning package for Python & has a lot of algorithms built-in. We can import our models from scikit learn.

# Importing train_test_split from sklearn.model_selection family
from sklearn.model_selection import train_test_split
# Split the data into 'X' array that contains the features to train on & a 'y' array with target variable. In this case the 'Clicked on Ad' column is what we are trying to predict.
# So, X gets all the numerical columns from our dataset except the target variable and y gets the target variable.

# First let's see the list of our column names
advertise.columns

# Assigning columns to X & y
X = advertise[['Daily_Time_ Spent _on_Site', 'Age', 'Area_Income', 'Daily Internet Usage', 'Male']]
y = advertise['Clicked_on_Ad']

# Splitting the data into train & test sets
# test_size is 0.33% of data that we want to allocate &random_state ensures a specific set of random splits on our data because this train test split is going to occur randomly
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)

# Building a Model
# A Logistic Regression model is created and we fit the model on training data.
# Import LogisticRegression from sklearn.linear_model family

from sklearn.linear_model import LogisticRegression

# Instantiate an instance of the linear regression model (Creating a linear regression object)

logreg = LogisticRegression()

# Fit the model on training data using a fit method
logreg.fit(X_train,y_train)

LogisticRegression(C=1.0, class_weight=None, dual=False, fit_intercept=True,
intercept_scaling=1, max_iter=100, multi_class='ovr', n_jobs=1,
          penalty='l2', random_state=None, solver='liblinear', tol=0.0001,
          verbose=0, warm_start=False)
# Predictions
# Predicting values for the testing data from our model.


# The predict method just takes X_test as a parameter, which means it just takes the features to draw predictions
predictions = logreg.predict(X_test)

# Below are the results of predicted click on Ads
predictions
# y_test contains the actual data of clicked on Ad
y_test
# Evaluations
# Now we need to see how far our predictions met the actual test data (y_test) by performing evaluations using classification report &confusion matrix on the target variable and the predictions.

# confusion matrix is used to evaluate the model behavior from a matrix. Below is how a confusion matrix looks like:


# Importing classification_report from sklearn.metrics family
from sklearn.metrics import classification_report
# Printing classification_report to see the results
print(classification_report(y_test, predictions))

# Importing a pure confusion matrix from sklearn.metrics family
from sklearn.metrics import confusion_matrix

# Printing the confusion_matrix
print(confusion_matrix(y_test, predictions))
# Results
# The results from evaluation are as follows:

