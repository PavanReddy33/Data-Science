import pandas as pd
import numpy as np
import networkx as nx 

Fb = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\NETWORK ANALYTICS\Datasets_Network Analytics\facebook.csv")
Ins = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\NETWORK ANALYTICS\Datasets_Network Analytics\instagram.csv")
Lin = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\NETWORK ANALYTICS\Datasets_Network Analytics\linkedin.csv")



# facebook
m1 = np.matrix(Fb)
g=nx.from_numpy_matrix(m1)
nx.draw(g)

        
# Instgram
m2 = np.matrix(Ins)
g2=nx.from_numpy_matrix(m2)
nx.draw(g2)



# linkedin
m3 = np.matrix(Lin)
g3=nx.from_numpy_matrix(m3)
nx.draw(g3)
