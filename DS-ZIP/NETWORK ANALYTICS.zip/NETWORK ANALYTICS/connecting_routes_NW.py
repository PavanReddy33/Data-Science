import pandas as pd
import networkx as nx 

# Degree Centrality

df1= pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\NETWORK ANALYTICS\Datasets_Network Analytics\connecting_routes.csv")

df1.info()

df=df1.iloc[:500,:]
airlines = nx.Graph()

airlines = nx.from_pandas_edgelist(df, source = 'AER', target = 'KZN')

print(nx.info(airlines))

b = nx.degree_centrality(airlines)  # Degree Centrality
print(b) 

pos = nx.spring_layout(airlines, k = 0.15)
nx.draw_networkx(airlines, pos, node_size = 5, node_color = 'blue')

# closeness centrality
closeness = nx.closeness_centrality(airlines)
print(closeness)

## Betweeness Centrality 
b = nx.betweenness_centrality(airlines) # Betweeness_Centrality
print(b)

## Eigen-Vector Centrality
evg = nx.eigenvector_centrality(airlines) # Eigen vector centrality
print(evg)

# cluster coefficient
cluster_coeff = nx.clustering(airlines)
print(cluster_coeff)

# Average clustering
cc = nx.average_clustering(airlines) 
print(cc)
