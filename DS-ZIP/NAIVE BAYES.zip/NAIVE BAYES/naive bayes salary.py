import pandas as pd

train1 = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\NAIVE BAYES\Datasets_Naive Bayes\SalaryData_Train.csv")
test1 = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\NAIVE BAYES\Datasets_Naive Bayes\SalaryData_Test.csv")

train1.info()


train1.describe()
test1.describe()

test1.columns
# dropping unwanted col


train = train1.drop(['maritalstatus','race','sex','native'],axis=1)
test = test1.drop(['maritalstatus','race','sex','native'],axis=1)


train.isna().sum()
test.isna().sum()

from sklearn.preprocessing import LabelEncoder
# creating instance of labelencoder
labelencoder = LabelEncoder()

train['workclass']= labelencoder.fit_transform(train['workclass'])
train['education']= labelencoder.fit_transform(train['education'])
train['occupation']= labelencoder.fit_transform(train['occupation'])
train['relationship']= labelencoder.fit_transform(train['relationship'])
train['Salary']= labelencoder.fit_transform(train['Salary'])

train.info()



test['workclass']= labelencoder.fit_transform(test['workclass'])
test['education']= labelencoder.fit_transform(test['education'])
test['occupation']= labelencoder.fit_transform(test['occupation'])
test['relationship']= labelencoder.fit_transform(test['relationship'])
test['Salary']= labelencoder.fit_transform(test['Salary'])


X_train = train.iloc[:,0:8]
X_test = test.iloc[:,0:8]
Y_train = train.iloc[:,-1]
Y_test = test.iloc[:,-1]


from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)


from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_train, Y_train)


y_pred  =  classifier.predict(X_test)

from sklearn.metrics import confusion_matrix,accuracy_score
confusion_matrix(Y_test, y_pred)
accuracy_score(Y_test,y_pred)



y_train  =  classifier.predict(X_train)
confusion_matrix(Y_train, y_train)
accuracy_score(Y_train,y_train)







