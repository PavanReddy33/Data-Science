
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer,TfidfTransformer


tweets = pd.read_csv(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\NAIVE BAYES\Datasets_Naive Bayes\Disaster_tweets_NB.csv",encoding = "ISO-8859-1")

tweets.info()

tweet= tweets.iloc[:,3:]


import re
stop_words = []
# Load the custom built Stopwords
with open(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\NLP TEXT MINING\Datasets NLP\stopwords_en.txt","r") as sw:
    stop_words = sw.read()




stop_words = stop_words.split("\n")

def cleaning_text(i):
    i = re.sub("[^A-Za-z" "]+"," ",i).lower()
    i = re.sub("[0-9" "]+"," ",i)
    w = []
    for word in i.split(" "):
        if len(word)>3:
            w.append(word)
    return (" ".join(w))



tweet.text = tweet.text.apply(cleaning_text)
tweet = tweet.loc[tweet.text != " ",:]


from sklearn.model_selection import train_test_split

tweet_train, tweet_test = train_test_split(tweet, test_size = 0.2)



def split_into_words(i):
    return [word for word in i.split(" ")]


emails_bow = CountVectorizer(analyzer = split_into_words).fit(tweet.text)



# Defining BOW for all messages
all_emails_matrix = emails_bow.transform(tweet.text)

# For training messages
train_emails_matrix = emails_bow.transform(tweet_train.text)

# For testing messages
test_emails_matrix = emails_bow.transform(tweet_test.text)

# Learning Term weighting and normalizing on entire emails
tfidf_transformer = TfidfTransformer().fit(all_emails_matrix)

# Preparing TFIDF for train emails
train_tfidf = tfidf_transformer.transform(train_emails_matrix)
train_tfidf.shape # (row, column)

# Preparing TFIDF for test emails
test_tfidf = tfidf_transformer.transform(test_emails_matrix)
test_tfidf.shape #  (row, column)

# Preparing a naive bayes model on training data set 

from sklearn.naive_bayes import MultinomialNB as MB

# Multinomial Naive Bayes
classifier_mb = MB()
classifier_mb.fit(train_tfidf, tweet_train.target)

# Evaluation on Test Data
test_pred_m = classifier_mb.predict(test_tfidf)
accuracy_test_m = np.mean(test_pred_m == tweet_test.target)
accuracy_test_m

from sklearn.metrics import accuracy_score
accuracy_score(test_pred_m, tweet_test.target) 

pd.crosstab(test_pred_m, tweet_test.target)
train_pred_m = classifier_mb.predict(train_tfidf)
accuracy_train_m = np.mean(train_pred_m == tweet_train.target)
accuracy_train_m





classifier_mb = MB(alpha=0.25)
classifier_mb.fit(train_tfidf, tweet_train.target)

# Evaluation on Test Data
test_pred_m = classifier_mb.predict(test_tfidf)
accuracy_test_m = np.mean(test_pred_m == tweet_test.target)
accuracy_test_m

from sklearn.metrics import accuracy_score
accuracy_score(test_pred_m, tweet_test.target) 

pd.crosstab(test_pred_m, tweet_test.target)
train_pred_m = classifier_mb.predict(train_tfidf)
accuracy_train_m = np.mean(train_pred_m == tweet_train.target)
accuracy_train_m














