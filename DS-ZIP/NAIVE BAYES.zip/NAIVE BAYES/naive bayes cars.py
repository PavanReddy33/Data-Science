
import pandas as pd

# loading the data
car = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\NAIVE BAYES\Datasets_Naive Bayes\NB_Car_Ad.csv")

# dropping the unwanted columns
car.drop(['User ID'],axis=1,inplace=True)
car.info()

car.describe()

# plots
import matplotlib.pyplot as plt

plt.hist(car.Purchased)
plt.hist(car.Age)

plt.boxplot(car.EstimatedSalary)
plt.boxplot(car.Age)


car.isna().sum() # no na values

car.var() # variance

# dummies
car=pd.get_dummies(car,drop_first=True)



# normalization
def norm_func(i):
    x = (i-i.min())/(i.max()-i.min())
    return (x)

car = norm_func(car)
car.describe()

from sklearn.model_selection import train_test_split

car_train, car_test = train_test_split(car, test_size = 0.2)

car_train.describe()
car_test.describe()

# splitting the data input and output
x_train=car_train.drop(['Purchased'],axis=1)
y_train=car_train['Purchased']

x_test=car_test.drop(['Purchased'],axis=1)
y_test=car_test['Purchased']


# naive bayes package
from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(x_train, y_train)

# test data
y_pred  =  classifier.predict(x_test)

from sklearn.metrics import confusion_matrix,accuracy_score
confusion_matrix(y_test, y_pred)
accuracy_score(y_test,y_pred)

# training data
train_pred  =  classifier.predict(x_train)
confusion_matrix(y_train, train_pred)
accuracy_score(y_train,train_pred)



