
import pandas as pd
import numpy as np


#df = pd.read_csv(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\K_MEANS CLUSTERING\Datasets_Kmeans\crime_data (1).csv")   
df = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\K_MEANS CLUSTERING\Datasets_Kmeans\crime_data (1).csv")   

df.info() # all the columns are in int

df.isna().sum() # no null values

### Identify duplicates records in the data
df.duplicated().sum()  # no duplicates

df.describe() # EDA

df.skew() # skewness
df.kurt() # kurtosis
df.var()

# plots

import matplotlib.pyplot as plt

plt.boxplot(df.Murder)
plt.boxplot(df.Assault)
plt.boxplot(df.UrbanPop)
plt.boxplot(df.Rape)


plt.bar(height = df.Rape, x = np.arange(1, 51, 1))
#We could see that Alaska and Nevada have the highest number of Rape cases.

# renaming the column
df.rename(columns={'Unnamed: 0':'States'},inplace=True)

# normalization

def norm_fun(i):
    x= (i - i.min()) / (i.max() - i.min())
    return (x)

norm = norm_fun(df.iloc[:,1:])

norm.describe()

from sklearn.cluster import	KMeans


###### scree plot or elbow curve ############
TWSS = []
k = list(range(2, 9))

for i in k:
    kmeans = KMeans(n_clusters = i)
    kmeans.fit(norm)
    TWSS.append(kmeans.inertia_)
    
TWSS
# Scree plot 
plt.plot(k, TWSS, 'ro-');plt.xlabel("No_of_Clusters");plt.ylabel("total_within_SS")

# Selecting 4 clusters from the above scree plot which is the optimum number of clusters 
model = KMeans(n_clusters = 4)
model.fit(norm)

model.labels_ # getting the labels of clusters assigned to each row 
mb = pd.Series(model.labels_)  # converting numpy array into pandas series object 
df['clust'] = mb # creating a  new column and assigning it to new column 

df.iloc[:, 1:].groupby(df.clust).mean()

df.to_csv("Kmeans_university.csv", encoding = "utf-8")

import os
os.getcwd()














