
import pandas as pd

df1 = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\HIERARCHICAL CLUSTERING\Dataset_Assignment Clustering\AutoInsurance.csv")   
data_sumary=df1.describe()

df=df1.drop(['Customer','State','Response','Effective To Date','Gender','Location Code','Marital Status'],axis=1)


df.info() #float64(2), int64(6), object(9)
df.isna().sum() # no null values


### Identify duplicates records in the data
df.duplicated().sum()  # 512 duplicates
df.drop_duplicates(inplace=True)

df.describe() # EDA

df.skew() # skewness
df.kurt() # kurtosis
df.var()

# plots

import matplotlib.pyplot as plt

plt.boxplot(df['Total Claim Amount'])
plt.boxplot(df['Number of Open Complaints'])
plt.boxplot(df['Income'])

plt.hist(df['Vehicle Size'])
plt.hist(df['Vehicle Class'])
plt.hist(df['Policy'])
plt.hist(df['Policy Type'])

# Personal L3     3159 more than 25% of the data
df['Policy'].value_counts()

#dummy variables
from sklearn.preprocessing import LabelEncoder
labelencoder=LabelEncoder()

df['Coverage'] = labelencoder.fit_transform(df['Coverage'])
df['Policy Type'] = labelencoder.fit_transform(df['Policy Type'])
df['Policy'] = labelencoder.fit_transform(df['Policy'])
df['Renew Offer Type'] = labelencoder.fit_transform(df['Renew Offer Type'])
df['Vehicle Class'] = labelencoder.fit_transform(df['Vehicle Class'])
df['Vehicle Size'] = labelencoder.fit_transform(df['Vehicle Size'])
df['Education'] = labelencoder.fit_transform(df['Education'])
df['EmploymentStatus'] = labelencoder.fit_transform(df['EmploymentStatus'])
df['Sales Channel'] = labelencoder.fit_transform(df['Sales Channel'])

df.info()

# normalization

def norm_fun(i):
    x= (i - i.min()) / (i.max() - i.min())
    return (x)

norm = norm_fun(df.iloc[:,:])

norm.describe()




from sklearn.cluster import	KMeans

TWSS = []
k = list(range(2, 9))

for i in k:
    kmeans = KMeans(n_clusters = i)
    kmeans.fit(norm)
    TWSS.append(kmeans.inertia_)
    
TWSS
# Scree plot 
plt.plot(k, TWSS, 'ro-');plt.xlabel("No_of_Clusters");plt.ylabel("total_within_SS")

# Selecting 3 clusters from the above scree plot which is the optimum number of clusters 
model = KMeans(n_clusters = 3)
model.fit(norm)

model.labels_ # getting the labels of clusters assigned to each row 
mb = pd.Series(model.labels_)  # converting numpy array into pandas series object 
df['clust'] = mb # creating a  new column and assigning it to new column 




summary=df.iloc[:, :].groupby(df.clust).mean()

df.to_csv("Kmeans_university.csv", encoding = "utf-8")

import os
os.getcwd()













