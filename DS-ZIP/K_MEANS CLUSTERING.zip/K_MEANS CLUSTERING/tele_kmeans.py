
import pandas as pd

df1 = pd.read_excel(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\K_MEANS CLUSTERING\Datasets_Kmeans\Telco_customer_churn (1).xlsx")   

df1.columns

# removing unwanted data
df = df1.drop(['Customer ID','Count','Quarter','Number of Referrals','Phone Service','Internet Service','Online Security','Online Backup','Streaming TV','Streaming Movies','Streaming Music','Paperless Billing','Payment Method'],axis=1)


df.info() 

df.isna().sum() # no null values

### Identify duplicates records in the data
df.duplicated().sum()  # no duplicates

df.describe() # EDA

df.skew() # skewness
df.kurt() # kurtosis
df.var()

# plots


import matplotlib.pyplot as plt
plt.hist(df['Offer'])
plt.hist(df['Referred a Friend'])
plt.hist(df['Internet Type'])
plt.hist(df['Device Protection Plan'])
plt.hist(df['Contract'])
plt.hist(df['Unlimited Data'])
plt.hist(df['Premium Tech Support'])


plt.boxplot(df['Total Revenue'])
plt.boxplot(df['Monthly Charge'])
plt.boxplot(df['Tenure in Months'])
plt.boxplot(df['Total Long Distance Charges'])

df.info()

# dummy variables
df_new_1 = pd.get_dummies(df, drop_first = True)
df_new_1.info()


# normalization

def norm_fun(i):
    x= (i - i.min()) / (i.max() - i.min())
    return (x)



norm = norm_fun(df_new_1.iloc[:,:])
norm.info()
norm.describe()


from sklearn.cluster import	KMeans

###### scree plot or elbow curve ############
TWSS = []
k = list(range(2, 9))

for i in k:
    kmeans = KMeans(n_clusters = i)
    kmeans.fit(norm)
    TWSS.append(kmeans.inertia_)
    
TWSS
# Scree plot 
plt.plot(k, TWSS, 'ro-');plt.xlabel("No_of_Clusters");plt.ylabel("total_within_SS")



# Selecting 3 clusters from the above scree plot which is the optimum number of clusters 
model = KMeans(n_clusters = 3)
model.fit(norm)

model.labels_ # getting the labels of clusters assigned to each row 
mb = pd.Series(model.labels_)  # converting numpy array into pandas series object 
df['clust'] = mb # creating a  new column and assigning it to new column 

df.head()


summary=df.iloc[:, :].groupby(df.clust).mean()

df.to_csv("Kmeans_tele.csv", encoding = "utf-8")

import os
os.getcwd()


