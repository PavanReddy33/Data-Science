############################################
########## PCA #########################

import pandas as pd

#df = pd.read_csv(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\PCA\Datasets_PCA\heart disease.csv")   
df = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\PCA\Datasets_PCA\wine.csv")   


df.info() # all the columns are in numeric

df.isna().sum() # no null values

### Identify duplicates records in the data
df.duplicated().sum()  # 0 duplicates


describe=df.describe() # EDA


df.skew() # skewness
df.kurt() # kurtosis
df.var()


import matplotlib.pyplot as plt

plt.boxplot(df.Alcohol)
plt.boxplot(df.Malic)
plt.boxplot(df.Ash)
plt.boxplot(df.Alcalinity)
plt.boxplot(df.Magnesium)
plt.boxplot(df.Phenols)
plt.boxplot(df.Flavanoids)
plt.boxplot(df.Nonflavanoids)
plt.boxplot(df.Proanthocyanins)
plt.boxplot(df.Color)
plt.boxplot(df.Hue)
plt.boxplot(df.Dilution)
plt.boxplot(df.Proline)



### Standardization
from sklearn.preprocessing import StandardScaler

# Initialise the Scaler
scaler = StandardScaler()
# To scale data
stand = scaler.fit_transform(df)

stand=pd.DataFrame(stand)
stand.describe()


###########################
##### Kmeans



from sklearn.cluster import	KMeans


###### scree plot or elbow curve ############
TWSS = []
k = list(range(2, 9))

for i in k:
    kmeans = KMeans(n_clusters = i)
    kmeans.fit(stand)
    TWSS.append(kmeans.inertia_)
    
TWSS
# Scree plot 
plt.plot(k, TWSS, 'ro-');plt.xlabel("No_of_Clusters");plt.ylabel("total_within_SS")

# Selecting 3 clusters from the above scree plot which is the optimum number of clusters 
model = KMeans(n_clusters = 3)
model.fit(stand)

model.labels_ # getting the labels of clusters assigned to each row 
mb = pd.Series(model.labels_)  # converting numpy array into pandas series object 

df['clust_1'] = mb # creating a  new column and assigning it to new column 

mean1=df.iloc[:, :].groupby(df.clust_1).mean()



################# Hierarchical Clustering

from scipy.cluster.hierarchy import linkage
import scipy.cluster.hierarchy as sch 

z = linkage(stand, method = "ward", metric = "euclidean")


plt.figure(figsize=(15, 8));plt.title('Hierarchical Clustering Dendrogram');plt.xlabel('Index');plt.ylabel('Crime')
sch.dendrogram(z, 
    leaf_rotation = 0,  # rotates the x axis labels
    leaf_font_size = 7 # font size for the x axis labels
)
plt.show()

# Now applying AgglomerativeClustering 
from sklearn.cluster import AgglomerativeClustering

h_complete = AgglomerativeClustering(n_clusters = 3, linkage = 'ward', affinity = "euclidean").fit(stand) 
h_complete.labels_


cluster_labels = pd.Series(h_complete.labels_)


df['clust_2'] = cluster_labels # creating a new column and assigning it to new column 

mean2=df.iloc[:, :14].groupby(df.clust_2).mean()



############################# PCA

from sklearn.decomposition import PCA
import numpy as np

pca = PCA(n_components = 14)
pca_values = pca.fit_transform(stand)

# The amount of variance that each PCA explains is 
var = pca.explained_variance_ratio_
var

pca.components_
pca.components_[0]
# Cumulative variance 

var1 = np.cumsum(np.round(var, decimals = 4) * 100)
var1

# Variance plot for PCA components obtained 
plt.plot(var1, color = "red")

# PCA scores
pca_values

pca_data = pd.DataFrame(pca_values)
pca_data.columns = "comp0", "comp1", "comp2", "comp3", "comp4", "comp5", "comp6", "comp7", "comp8", "comp9", "comp10", "comp11", "comp12", "comp13"

final_2 = pd.concat([pca_data.iloc[:, 0:3]], axis = 1)
# as requested by the assisment to condider first 3 PCs.




#############################
####### K-means for first 3 PCA data

###### scree plot or elbow curve ############
TWSS1 = []
k = list(range(2, 9))

for i in k:
    kmeans = KMeans(n_clusters = i)
    kmeans.fit(final_2)
    TWSS1.append(kmeans.inertia_)
    
TWSS1
# Scree plot 
plt.plot(k, TWSS1, 'ro-');plt.xlabel("No_of_Clusters");plt.ylabel("total_within_SS")

# Selecting 3 clusters from the above scree plot which is the optimum number of clusters 
model2 = KMeans(n_clusters = 3)
model2.fit(final_2)

model2.labels_ # getting the labels of clusters assigned to each row 
mb1 = pd.Series(model2.labels_)  # converting numpy array into pandas series object 

df['clust_3'] = mb1 # creating a  new column and assigning it to new column 

mean3=df.iloc[:, :14].groupby(df.clust_3).mean()






################# Hierarchical Clustering


z2 = linkage(final_2, method = "ward", metric = "euclidean")


plt.figure(figsize=(15, 8));plt.title('Hierarchical Clustering Dendrogram');plt.xlabel('Index');plt.ylabel('Crime')
sch.dendrogram(z2, 
    leaf_rotation = 0,  # rotates the x axis labels
    leaf_font_size = 7 # font size for the x axis labels
)
plt.show()

# Now applying AgglomerativeClustering 
from sklearn.cluster import AgglomerativeClustering

h_complete2 = AgglomerativeClustering(n_clusters = 3, linkage = 'ward', affinity = "euclidean").fit(final_2) 
h_complete2.labels_


cluster_labels2 = pd.Series(h_complete2.labels_)


df['clust_4'] = cluster_labels2 # creating a new column and assigning it to new column 

mean4=df.iloc[:, :14].groupby(df.clust_4).mean()

