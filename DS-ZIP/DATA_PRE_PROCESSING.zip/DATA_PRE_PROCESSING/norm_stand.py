import numpy as np
import pandas as pd

# load the dataset
# use modified ethnic dataset
df = pd.read_csv(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\DATA_PRE_PROCESSING\DataSets-Data Pre Processing\DataSets\Seeds_data.csv")

# for doing modifications

df.dtypes #data types
df.info() #gives data types with more info
df.isna().sum() # Sum of null/na vaules

### Identify duplicates records in the data
df.duplicated().sum()

# EDA
df.describe()

# Third moment business decision
df.skew()

# Fourth moment business decision
df.kurt()

df.var() # variance of numeric variables

import matplotlib.pyplot as plt
import numpy as np

df.shape
df.columns

plt.hist(df.length) #histogram
plt.hist(df.Compactness , color='red')

plt.boxplot(df.Width) #boxplot
plt.boxplot(df.Assymetry_coeff) #boxplot
plt.boxplot(df.len_ker_grove) #boxplot


##########################################
### Standardization
from sklearn.preprocessing import StandardScaler

# Initialise the Scaler
scaler = StandardScaler()
# To scale data
df1 = scaler.fit_transform(df)
# Convert the array back to a dataframe
dataset = pd.DataFrame(df1)
res = dataset.describe()

df_nor = pd.read_csv(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\DATA_PRE_PROCESSING\DataSets-Data Pre Processing\DataSets\Seeds_data.csv")

### Normalization

### Normalization function - Custom Function
# Range converts to: 0 to 1
def norm_func(i):
    x=(i-i.min())/(i.max()-i.min())
    return(x)

norm = norm_func(df_nor)
b = norm.describe()
