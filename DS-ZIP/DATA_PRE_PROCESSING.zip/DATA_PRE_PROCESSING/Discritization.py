# Discritization 

import pandas as pd
import numpy as np
df = pd.read_csv("C:\\Users\\pavva\\OneDrive\\Documents\\DATA SCIENCE\\DATA_PRE_PROCESSING\\DataSets-Data Pre Processing\\DataSets\\iris.csv")
df.head() #top 5
df.describe()

# dropped Unnamed: 0 as it does not hold any key info
df.drop(['Unnamed: 0'], axis=1, inplace=True)

df.dtypes #data types
df.info() #gives data types with more info
df.isna().sum() # Sum of null/na vaules

### Identify duplicates records in the data

df.duplicated().sum()
df = df.drop_duplicates()

# EDA
df.describe()

# Third moment business decision
df.skew()

# Fourth moment business decision
df.kurt()

df.var() # variance of numeric variables

output=df['Species']
input=df.iloc[:,0:4]

final = input[:].apply(np.ceil) 
final['species']=output
