#####################

# TRANSFORMATIONS

import pandas as pd

# Read data into Python
df = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\DATA_PRE_PROCESSING\DataSets-Data Pre Processing\DataSets\calories_consumed.csv")

import scipy.stats as stats
import pylab


df.dtypes #data types
df.info() #gives data types with more info
df.isna().sum() # Sum of null/na vaules

### Identify duplicates records in the data
df.duplicated().sum()

# EDA
df.describe()

# Third moment business decision
df.skew()

# Fourth moment business decision
df.kurt()

df.var() # variance of numeric variables

df.columns
# Checking Whether data is normally distributed

#renaming columns
df.rename(columns = {'Weight gained (grams)' : 'weight', 'Calories Consumed' : 'Calories'}, inplace = True)

stats.probplot(df.weight, dist="norm", plot=pylab)

stats.probplot(df.Calories, dist="norm", plot=pylab)

import numpy as np

# Transformation to make workex variable normal
stats.probplot(np.log(df.weight), dist="norm", plot=pylab)
stats.probplot(np.log(df.Calories), dist="norm", plot=pylab)
