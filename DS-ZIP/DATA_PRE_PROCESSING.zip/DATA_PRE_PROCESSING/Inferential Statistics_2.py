########################
# Infer_stast_2 ##########

import pandas as pd

# load the dataset
# use modified ethnic dataset
df = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\DATA_PRE_PROCESSING\DataSets-Data Pre Processing\DataSets\data_for_Inferential Statistics.csv")

# for doing modifications

df.dtypes #data types
df.info() #gives data types with more info
df.isna().sum() # Sum of null/na vaules

### Identify duplicates records in the data
df.duplicated().sum()
range= max(df.Measure_X)-min(df.Measure_X)
range
# EDA
df.describe()

# Third moment business decision
df.skew()

# Fourth moment business decision
df.kurt()

df.var() 

import matplotlib.pyplot as plt
plt.boxplot(df.Measure_X)
