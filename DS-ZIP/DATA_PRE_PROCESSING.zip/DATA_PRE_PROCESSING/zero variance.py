import pandas as pd

df = pd.read_csv("C:\\Users\\pavva\\OneDrive\\Documents\\DATA SCIENCE\\DATA_PRE_PROCESSING\\DataSets-Data Pre Processing\\DataSets\\Z_dataset.csv")


df.dtypes #data types
df.info() #gives data types with more info
df.isna().sum() # Sum of null/na vaules


### Identify duplicates records in the data
df.duplicated().sum()
# OR
duplicate = df.duplicated()
duplicate
sum(duplicate)
#### zero variance and near zero variance ######

#dropping "ID" column as it does not hold any key information.
Data=df.drop(['Id'], axis=1)
Data.describe() #gives basic EDA

# Third moment business decision
Data.skew()

# Fourth moment business decision
Data.kurt()

Variance=Data.var() # variance of numeric variables
Variance



# no column has a variance of 0 or closest to 0
# Hence, no column has been removed.






