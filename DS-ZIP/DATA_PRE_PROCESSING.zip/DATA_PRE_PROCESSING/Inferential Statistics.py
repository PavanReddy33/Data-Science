
import pandas as pd

# load the dataset
# use modified ethnic dataset
df = pd.read_excel(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\DATA_TYPES_EDA\Assignment_module.xlsx")

# for doing modifications

df.dtypes #data types
df.info() #gives data types with more info
df.isna().sum() # Sum of null/na vaules

### Identify duplicates records in the data
df.duplicated().sum()
range= max(df.Points)-min(df.Points)
range1= max(df.Score)-min(df.Score)
range2=max(df.Weigh)-min(df.Weigh)
# EDA
df.describe()

# Third moment business decision
df.skew()

# Fourth moment business decision
df.kurt()

df.var() 
