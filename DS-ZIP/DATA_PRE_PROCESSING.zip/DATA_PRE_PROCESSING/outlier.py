import pandas as pd
import numpy as np
import seaborn as sns

df = pd.read_csv("C:/Users/pavan kumar/OneDrive/Documents/DATA SCIENCE/DATA_PRE_PROCESSING/DataSets-Data Pre Processing/DataSets/boston_data.csv")
df.dtypes
df.info()
df.describe
df.isna().sum()

df.skew()
df.kurt()
df.var()


#1>
sns.boxplot(df.crim)
#OUTLIER

IQR = df['crim'].quantile(0.75) - df['crim'].quantile(0.25)
lower_limit = df['crim'].quantile(0.25) - (IQR * 1.5)
upper_limit = df['crim'].quantile(0.75) + (IQR * 1.5)
df.shape

############### Replace ###############
# Now let's replace the outliers by the maximum and minimum limit
df['df_replaced'] = pd.DataFrame(np.where(df['crim'] > upper_limit, upper_limit, np.where(df['crim'] < lower_limit, lower_limit, df['crim'])))
sns.boxplot(df.df_replaced)

# OUTLIES HAS BEEN REMOVED


#2>
sns.boxplot(df.zn)
#outliers


IQR2 = df['zn'].quantile(0.75) - df['zn'].quantile(0.25)
lower_limit2 = df['zn'].quantile(0.25) - (IQR * 1.5)
upper_limit2 = df['zn'].quantile(0.75) + (IQR * 1.5)


############### 2.Replace ###############
# Now let's replace the outliers by the maximum and minimum limit
df['df_replaced'] = pd.DataFrame(np.where(df['zn'] > upper_limit2, upper_limit2, np.where(df['zn'] < lower_limit2, lower_limit2, df['zn'])))
sns.boxplot(df.df_replaced)


# OUTLIES HAS BEEN REMOVED


#3>
sns.boxplot(df.indus)
# NO OUTLIER
#4>
sns.boxplot(df.chas)
#outliers BUT IT HAS ONLY 0 AND 1.
#5>
sns.boxplot(df.nox)
# NO OUTLIER



#6>
sns.boxplot(df.rm)
# outliers

###############  Winsorization ###############
from feature_engine.outliers import Winsorizer
winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['rm'])

df_t = winsor.fit_transform(df[['rm']])

# lets see boxplot
sns.boxplot(df_t.rm)
# OUTLIES HAS BEEN REMOVED


#7>
sns.boxplot(df.age)
#NO OUTLIER

#8>
sns.boxplot(df.dis)
# outliers
winsor1 = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['dis'])

df_t1 = winsor1.fit_transform(df[['dis']])

# lets see boxplot
sns.boxplot(df_t1.dis)

#9>
sns.boxplot(df.rad)
#NO OUTLIER
#10>
sns.boxplot(df.tax)
# No outliers 


#11>
sns.boxplot(df.ptratio)
#OUTLIER
winsor1 = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['dis'])

df_t1 = winsor1.fit_transform(df[['dis']])

# lets see boxplot
sns.boxplot(df_t1.dis)



#12>
sns.boxplot(df.black)
#  outliers
winsor2 = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['black'])

df_t2 = winsor2.fit_transform(df[['black']])

# lets see boxplot
sns.boxplot(df_t2.black)



#13>
sns.boxplot(df.lstat)
#OUTLIER
winsor3 = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['lstat'])

df_t3 = winsor3.fit_transform(df[['lstat']])

# lets see boxplot
sns.boxplot(df_t3.lstat)


#14>
sns.boxplot(df.medv)
#outliers 
winsor4 = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['medv'])

df_t4 = winsor4.fit_transform(df[['medv']])

# lets see boxplot
sns.boxplot(df_t1.dis)



#TOTAL NUMBER OF COLUMN IS 14
#NUMBER OF COLUMNS THAT HAS OUTLIERS IS 8
#NUMBER OF COLUMNS THAT HAS NO OUTLIERS IS 6

