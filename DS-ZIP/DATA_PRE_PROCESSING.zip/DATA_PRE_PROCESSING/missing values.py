#################### Missing Values Imputation

import numpy as np
import pandas as pd

# load the dataset
# use modified ethnic dataset
df = pd.read_csv("C:\\Users\\pavva\\OneDrive\\Documents\\DATA SCIENCE\\DATA_PRE_PROCESSING\\DataSets-Data Pre Processing\\DataSets\\claimants.csv")

# for doing modifications

df.dtypes #data types
df.info() #gives data types with more info
df.isna().sum() # Sum of null/na vaules

### Identify duplicates records in the data
df.duplicated().sum()

# EDA
df.describe()

# Third moment business decision
df.skew()

# Fourth moment business decision
df.kurt()

df.var() # variance of numeric variables


# Create an imputer object that fills 'Nan' values
# Mean and Median imputer are used for numeric data
# Mode is used for discrete data
# Even though there are no categorical data in the data set
# we will use mode imputer for CLMSEX CLMINSUR SEATBELT 
# because the type of data these column has is 0 and 1 and mean imputer for CLMAGE

# for Mean, Meadian, Mode imputation we can use Simple Imputer or df.fillna()
from sklearn.impute import SimpleImputer

# For CLMSEX CLMINSUR SEATBELT 
# Mode Imputer
mode_imputer = SimpleImputer(missing_values=np.nan, strategy='most_frequent')
df["CLMSEX"] = pd.DataFrame(mode_imputer.fit_transform(df[["CLMSEX"]]))
df["CLMINSUR"] = pd.DataFrame(mode_imputer.fit_transform(df[["CLMINSUR"]]))
df["SEATBELT"] = pd.DataFrame(mode_imputer.fit_transform(df[["SEATBELT"]]))

df.isnull().sum()

# Mean Imputer for CLMAGE
mean_imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
df["CLMAGE"] = pd.DataFrame(mean_imputer.fit_transform(df[["CLMAGE"]]))
#df["CLMSEX"].isna().sum()

df.isnull().sum()
# As we can see there are no missing values
