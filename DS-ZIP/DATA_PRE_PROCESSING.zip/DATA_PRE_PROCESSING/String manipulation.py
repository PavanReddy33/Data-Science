################################################################
#################### String manipulation #######################

# 1> Create a string “Grow Gratitude”.

word= "Grow Gratitude"

#a)	How do you access the letter “G” of “Growth”?
word[0]

# b)	How do you find the length of the string?
len(word)

# c)	Count how many times “G” is in the string.
word.count('G')



# 2.	Create a string “Being aware of a single shortcoming within
    #yourself is far more useful than being aware of a thousand in someone else.”
    
string= "Being aware of a single shortcoming within yourself is far more useful than being aware of a thousand in someone else."

# a)	Count the number of characters in the string.

len(string)

# a)	Count the number of unique characters in the string.

char= set(string)
len(char)



# 3.	Create a string "Idealistic as it may sound, altruism should be the driving force in 
#   business, not just competition and a desire for wealth"

string_3 = "Idealistic as it may sound, altruism should be the driving force in business, not just competition and a desire for wealth"


# a)	get one char of the word

string_3[1]
string_3[0:10]

# ⦁	get the first three char

string_3[0:3]


# ⦁	get the last three char

string_3[-3:]


# 4) create a string "stay positive and optimistic". Now write a code to split on whitespace.

word_1='stay positive and optimistic'


#Write a code to find if:
#⦁	The string starts with “H”

word_1.find('H')
#⦁	The string ends with “d”
word_1.find('d')
#⦁	The string ends with “c”
word_1.find('c')



# 5) 	Write a code to print " 🪐 " one hundred and eight times. 
print( " 🪐  "* 108 )# 


# 6)	Create a string “Grow Gratitude” and write a code to replace “Grow” with “Growth of”


letter = 'Grow Gratitude'

letter.replace('Grow', 'Growth of')



# 7) You have noticed that the story is printed in a reversed order. Rectify the same and write a code to print the same story in a correct order.

rev = ".elgnujehtotniffo deps mehtfohtoB .eerfnoilehttesotseporeht no dewangdnanar eh ,ylkciuQ .elbuortninoilehtdecitondnatsapdeklawesuomeht ,nooS .repmihwotdetratsdnatuotegotgnilggurts saw noilehT .eert a tsniagapumihdeityehT .mehthtiwnoilehtkootdnatserofehtotniemacsretnuhwef a ,yad enO .ogmihteldnaecnedifnocs’esuomeht ta dehgualnoilehT ”.emevasuoy fi yademosuoyotplehtaergfo eb lliw I ,uoyesimorp I“ .eerfmihtesotnoilehtdetseuqeryletarepsedesuomehtnehwesuomehttaeottuoba saw eH .yrgnaetiuqpuekow eh dna ,peels s’noilehtdebrutsidsihT .nufroftsujydobsihnwoddnapugninnurdetratsesuom a nehwelgnujehtnignipeelsecno saw noil A"

print (''.join(reversed(rev)))
















