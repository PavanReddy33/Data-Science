################## Dummy Variables ###############

import pandas as pd

# we use ethinc diversity dataset
df = pd.read_csv("C:\\Users\\pavan kumar\\OneDrive\\Documents\\DATA SCIENCE\\DATA_PRE_PROCESSING\\DataSets-Data Pre Processing\\DataSets\\animal_category.csv")

df.columns # column names
df.shape # will give u shape of the dataframe

# drop emp_name column
df.drop(['Index'], axis=1, inplace=True)
df.dtypes

# Create dummy variables
df_new = pd.get_dummies(df)
df_new_1 = pd.get_dummies(df, drop_first = True)
# we have created dummies for all categorical columns

##### One Hot Encoding works
df.columns
df_one_hot = df[['Animals', 'Gender', 'Homly', 'Types']]


from sklearn.preprocessing import OneHotEncoder
# Creating instance of One Hot Encoder
enc = OneHotEncoder() # initializing method

enc_df = pd.DataFrame(enc.fit_transform(df_one_hot.iloc[:, :]).toarray())
# All the categorical data has been converted to numeric data


#######################
# Label Encoder

# Label encoder is used only for ordinal data
# Just for understanding purpose the below codes are executed

from sklearn.preprocessing import LabelEncoder
# creating instance of labelencoder
labelencoder = LabelEncoder()

# Data Split into Input and Output variables
X = df.iloc[:, :3]

y = df['Race']
y = df.iloc[:, 3:] # Alternative approach

df.columns

X['Animals']= labelencoder.fit_transform(X['Animals'])
X['Gender'] = labelencoder.fit_transform(X['Gender'])
X['Homly'] = labelencoder.fit_transform(X['Homly'])

y['Types'] = labelencoder.fit_transform(y['Types'])

# All the categorical data has been converted to numeric data