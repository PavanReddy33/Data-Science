
################ Type casting #################
import pandas as pd

data = pd.read_csv(r"C:\Users\pavan kumar\OneDrive\Documents\DATA SCIENCE\DATA_PRE_PROCESSING\DataSets-Data Pre Processing\DataSets\OnlineRetail.csv",encoding= 'unicode_escape')
data.dtypes


data.info()

data.isna().sum()
data=data.dropna()
data.isna().sum()

data.dtypes

# Now we will convert 'float64' into 'int64' type. 
data.UnitPrice  = data.UnitPrice.astype('int64')
data.dtypes

data.CustomerID  = data.CustomerID.astype('int64')
data.dtypes




###############################################
### Identify duplicates records in the data ###

duplicate = data.duplicated()
duplicate
sum(duplicate)

# Removing Duplicates
data = data.drop_duplicates()
duplicate1=data.duplicated()
sum(duplicate1)

# Exploratory Data Analysis
# Measures of Central Tendency / First moment business decision
data.UnitPrice.mean() # '.' is used to refer to the variables within object
data.UnitPrice.median()

info=data.describe()
info


from scipy import stats
stats.mode(data.Country)

# Measures of Dispersion / Second moment business decision
data.UnitPrice.var() # variance
data.UnitPrice.std() # standard deviation
range = max(data.UnitPrice) - min(data.UnitPrice) # range
range
range1 = max(data.Quantity) - min(data.Quantity) # range
range1

# Third moment business decision
data.UnitPrice.skew()
data.Quantity.skew()

# Fourth moment business decision
data.UnitPrice.kurt()
data.Quantity.kurt()




# Data Visualization
import matplotlib.pyplot as plt
import numpy as np

data.shape

plt.bar(height = data.UnitPrice, x = np.arange(1, 401596, 1)) # initializing the parameter

plt.hist(data.UnitPrice) #histogram
plt.hist(data.Quantity, color='red')

help(plt.hist)

plt.boxplot(data.Quantity) #boxplot
plt.boxplot(data.UnitPrice)

