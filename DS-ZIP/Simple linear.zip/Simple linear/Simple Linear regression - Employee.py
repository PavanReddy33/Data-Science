import pandas as pd   
import numpy as np 
import matplotlib.pyplot as plt

emp = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/19- Simple Linear Regression/Assignments/Datasets/emp_data.csv")
emp.columns

############### EDA ---> First Moment Business ##############

emp.mean()
emp.median()
emp.mode()

############### EDA ---> Second Moment Business ##############

emp.var()
emp.std()
max(emp["SalaryHike"])-min(emp["SalaryHike"])
max(emp["ChurnOutRate"])-min(emp["ChurnOutRate"])

############### EDA ---> Third Moment Business #############

emp.skew()

############### EDA ---> Fourth Moment Business #############

emp.kurt()

############### EDA ---> Fifth Moment Business #############

plt.boxplot(emp)
plt.hist(emp) 
plt.scatter(x = emp["SalaryHike"], y = emp["ChurnOutRate"], color = 'green') 

########## correlation coefficient ############
np.corrcoef(emp["SalaryHike"], emp["ChurnOutRate"]) 

########## Covariance ############
np.cov(emp["SalaryHike"], emp["ChurnOutRate"])[0, 1]

import statsmodels.formula.api as smf

######### Simple Linear Regression #######
model = smf.ols('ChurnOutRate ~ SalaryHike', data = emp).fit()
model.summary()

pred1 = model.predict(pd.DataFrame(emp['SalaryHike']))

### Regression Line ###
plt.scatter(emp.SalaryHike, emp.ChurnOutRate)
plt.plot(emp.SalaryHike, pred1, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

### Error calculation ###
res1 = emp.ChurnOutRate - pred1
res_sqr1 = res1 * res1
mse1 = np.mean(res_sqr1)
rmse1 = np.sqrt(mse1)
rmse1

########### Model building on Transformed Data #############
###### Log Transformation ### 

plt.scatter(x = np.log(emp['SalaryHike']), y = emp['ChurnOutRate'], color = 'brown')
np.corrcoef(np.log(emp.SalaryHike), emp.ChurnOutRate) #correlation

model2 = smf.ols('ChurnOutRate ~ np.log(SalaryHike)', data = emp).fit()
model2.summary()

pred2 = model2.predict(pd.DataFrame(emp['SalaryHike']))

# Regression Line
plt.scatter(np.log(emp.SalaryHike), emp.ChurnOutRate)
plt.plot(np.log(emp.SalaryHike), pred2, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

# Error calculation
res2 = emp.ChurnOutRate - pred2
res_sqr2 = res2 * res2
mse2 = np.mean(res_sqr2)
rmse2 = np.sqrt(mse2)
rmse2


############### Exponential transformation ############
######### x = SalaryHike; y = log(ChurnOutRate) ######

plt.scatter(x = emp['SalaryHike'], y = np.log(emp['ChurnOutRate']), color = 'orange')
np.corrcoef(emp.SalaryHike, np.log(emp.ChurnOutRate)) #correlation

model3 = smf.ols('np.log(ChurnOutRate) ~ SalaryHike', data = emp).fit()
model3.summary()

pred3 = model3.predict(pd.DataFrame(emp['SalaryHike']))
pred3_at = np.exp(pred3)
pred3_at

# Regression Line
plt.scatter(emp.SalaryHike, np.log(emp.ChurnOutRate))
plt.plot(emp.SalaryHike, pred3, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

# Error calculation
res3 = emp.ChurnOutRate - pred3_at
res_sqr3 = res3 * res3
mse3 = np.mean(res_sqr3)
rmse3 = np.sqrt(mse3)
rmse3


############## Polynomial transformation ###############
## x = SalaryHike; x^2 = SalaryHike*SalaryHike; y = log(ChurnOutRate) ##

model4 = smf.ols('np.log(ChurnOutRate) ~ SalaryHike + I(SalaryHike*SalaryHike)', data = emp).fit()
model4.summary()

pred4 = model4.predict(pd.DataFrame(emp))
pred4_at = np.exp(pred4)
pred4_at

# Regression line
from sklearn.preprocessing import PolynomialFeatures
poly_reg = PolynomialFeatures(degree = 2)
X = emp.iloc[:, 0:1].values
X_poly = poly_reg.fit_transform(X)
# y = emp.iloc[:, 1].values


plt.scatter(emp.SalaryHike, np.log(emp.ChurnOutRate))
plt.plot(X, pred4, color = 'red')
plt.legend(['Predicted line', 'Observed data'])
plt.show()


# Error calculation
res4 = emp.ChurnOutRate - pred4_at
res_sqr4 = res4 * res4
mse4 = np.mean(res_sqr4)
rmse4 = np.sqrt(mse4)
rmse4


### Choose the best model using RMSE ###
data = {"MODEL":pd.Series(["SLR", "Log model", "Exp model", "Poly model"]), "RMSE":pd.Series([rmse1, rmse2, rmse3, rmse4])}
table_rmse = pd.DataFrame(data)
table_rmse


####################
## The best model ##

from sklearn.model_selection import train_test_split

train, test = train_test_split(emp, test_size = 0.2)

finalmodel = smf.ols('np.log(ChurnOutRate) ~ SalaryHike + I(SalaryHike*SalaryHike)', data = train).fit()
finalmodel.summary()

# Predict on test data
test_pred = finalmodel.predict(pd.DataFrame(test))
pred_test_ChurnOutRate = np.exp(test_pred)
pred_test_ChurnOutRate

# Model Evaluation on Test data
test_res = test.ChurnOutRate - pred_test_ChurnOutRate
test_sqrs = test_res * test_res
test_mse = np.mean(test_sqrs)
test_rmse = np.sqrt(test_mse)
test_rmse


# Prediction on train data
train_pred = finalmodel.predict(pd.DataFrame(train))
pred_train_ChurnOutRate = np.exp(train_pred)
pred_train_ChurnOutRate

# Model Evaluation on train data
train_res = train.ChurnOutRate - pred_train_ChurnOutRate
train_sqrs = train_res * train_res
train_mse = np.mean(train_sqrs)
train_rmse = np.sqrt(train_mse)
train_rmse
