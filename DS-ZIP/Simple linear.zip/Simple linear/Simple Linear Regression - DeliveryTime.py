import pandas as pd   
import numpy as np 
import matplotlib.pyplot as plt

delivery = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/19- Simple Linear Regression/Assignments/Datasets/delivery_time.csv")
delivery.columns

############### EDA ---> First Moment Business ##############

delivery.mean()
delivery.median()
delivery.mode()

############### EDA ---> Second Moment Business ##############

delivery.var()
delivery.std()
max(delivery["DeliveryTime"])-min(delivery["DeliveryTime"])
max(delivery["SortingTime"])-min(delivery["SortingTime"])

############### EDA ---> Third Moment Business #############

delivery.skew()

############### EDA ---> Fourth Moment Business #############

delivery.kurt()

############### EDA ---> Fifth Moment Business #############

plt.boxplot(delivery)
plt.hist(delivery) 
plt.scatter(x = delivery["DeliveryTime"], y = delivery["SortingTime"], color = 'green') 

########## correlation coefficient ############
np.corrcoef(delivery["DeliveryTime"], delivery["SortingTime"]) 

########## Covariance ############
np.cov(delivery["DeliveryTime"], delivery["SortingTime"])[0, 1]

import statsmodels.formula.api as smf

######### Simple Linear Regression #######
model = smf.ols('SortingTime ~ DeliveryTime', data = delivery).fit()
model.summary()

pred1 = model.predict(pd.DataFrame(delivery['DeliveryTime']))

### Regression Line ###
plt.scatter(delivery.DeliveryTime, delivery.SortingTime)
plt.plot(delivery.DeliveryTime, pred1, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

### Error calculation ###
res1 = delivery.SortingTime - pred1
res_sqr1 = res1 * res1
mse1 = np.mean(res_sqr1)
rmse1 = np.sqrt(mse1)
rmse1


########### Model building on Transformed Data #############
###### Log Transformation ###  x = log(DeliveryTime); y = SortingTime ######

plt.scatter(x = np.log(delivery['DeliveryTime']), y = delivery['SortingTime'], color = 'brown')
np.corrcoef(np.log(delivery.DeliveryTime), delivery.SortingTime) #correlation

model2 = smf.ols('SortingTime ~ np.log(DeliveryTime)', data = delivery).fit()
model2.summary()

pred2 = model2.predict(pd.DataFrame(delivery['DeliveryTime']))

# Regression Line
plt.scatter(np.log(delivery.DeliveryTime), delivery.SortingTime)
plt.plot(np.log(delivery.DeliveryTime), pred2, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

# Error calculation
res2 = delivery.SortingTime - pred2
res_sqr2 = res2 * res2
mse2 = np.mean(res_sqr2)
rmse2 = np.sqrt(mse2)
rmse2

############### Exponential transformation ############
######### x = DeliveryTime; y = log(SortingTime) ######

plt.scatter(x = delivery['DeliveryTime'], y = np.log(delivery['SortingTime']), color = 'orange')
np.corrcoef(delivery.DeliveryTime, np.log(delivery.SortingTime)) #correlation

model3 = smf.ols('np.log(SortingTime) ~ DeliveryTime', data = delivery).fit()
model3.summary()

pred3 = model3.predict(pd.DataFrame(delivery['DeliveryTime']))
pred3_at = np.exp(pred3)
pred3_at

# Regression Line
plt.scatter(delivery.DeliveryTime, np.log(delivery.SortingTime))
plt.plot(delivery.DeliveryTime, pred3, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

# Error calculation
res3 = delivery.SortingTime - pred3_at
res_sqr3 = res3 * res3
mse3 = np.mean(res_sqr3)
rmse3 = np.sqrt(mse3)
rmse3


############## Polynomial transformation ###############
## x = DeliveryTime; x^2 = DeliveryTime*DeliveryTime; y = log(SortingTime) ##

model4 = smf.ols('np.log(SortingTime) ~ DeliveryTime + I(DeliveryTime*DeliveryTime)', data = delivery).fit()
model4.summary()

pred4 = model4.predict(pd.DataFrame(delivery))
pred4_at = np.exp(pred4)
pred4_at

# Regression line
from sklearn.preprocessing import PolynomialFeatures
poly_reg = PolynomialFeatures(degree = 2)
X = delivery.iloc[:, 0:1].values
X_poly = poly_reg.fit_transform(X)
# y = calories.iloc[:, 1].values


plt.scatter(delivery.DeliveryTime, np.log(delivery.SortingTime))
plt.plot(X, pred4, color = 'red')
plt.legend(['Predicted line', 'Observed data'])
plt.show()


# Error calculation
res4 = delivery.SortingTime - pred4_at
res_sqr4 = res4 * res4
mse4 = np.mean(res_sqr4)
rmse4 = np.sqrt(mse4)
rmse4


### Choose the best model using RMSE ###
data = {"MODEL":pd.Series(["SLR", "Log model", "Exp model", "Poly model"]), "RMSE":pd.Series([rmse1, rmse2, rmse3, rmse4])}
table_rmse = pd.DataFrame(data)
table_rmse

####################
## The best model ##

from sklearn.model_selection import train_test_split

train, test = train_test_split(delivery, test_size = 0.2)

finalmodel = smf.ols('np.log(SortingTime) ~ DeliveryTime + I(DeliveryTime*DeliveryTime)', data = train).fit()
finalmodel.summary()

# Predict on test data
test_pred = finalmodel.predict(pd.DataFrame(test))
pred_test_SortingTime = np.exp(test_pred)
pred_test_SortingTime

# Model Evaluation on Test data
test_res = test.SortingTime - pred_test_SortingTime
test_sqrs = test_res * test_res
test_mse = np.mean(test_sqrs)
test_rmse = np.sqrt(test_mse)
test_rmse


# Prediction on train data
train_pred = finalmodel.predict(pd.DataFrame(train))
pred_train_SortingTime = np.exp(train_pred)
pred_train_SortingTime

# Model Evaluation on train data
train_res = train.SortingTime - pred_train_SortingTime
train_sqrs = train_res * train_res
train_mse = np.mean(train_sqrs)
train_rmse = np.sqrt(train_mse)
train_rmse



























