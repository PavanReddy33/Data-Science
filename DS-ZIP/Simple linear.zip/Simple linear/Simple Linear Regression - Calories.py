import pandas as pd   
import numpy as np 
import matplotlib.pyplot as plt

calories = pd.read_csv("C:/Users/Ultimate/Desktop/Data Science/Assignments/19- Simple Linear Regression/Assignments/Datasets/calories_consumed.csv")
calories.columns

############### EDA ---> First Moment Business ##############

calories.mean()
calories.median()
calories.mode()

############### EDA ---> Second Moment Business ##############

calories.var()
calories.std()
max(calories["WeightGained"])-min(calories["WeightGained"])
max(calories["CaloriesConsumed"])-min(calories["CaloriesConsumed"])

############### EDA ---> Third Moment Business #############

calories.skew()

############### EDA ---> Fourth Moment Business #############

calories.kurt()

############### EDA ---> Fifth Moment Business #############

plt.boxplot(calories)
plt.hist(calories) 
plt.scatter(x = calories["WeightGained"], y = calories["CaloriesConsumed"], color = 'green') 

########## correlation coefficient ############
np.corrcoef(calories["WeightGained"], calories["CaloriesConsumed"]) 

########## Covariance ############
np.cov(calories["WeightGained"], calories["CaloriesConsumed"])[0, 1]

import statsmodels.formula.api as smf

###### Simple Linear Regression #######
model = smf.ols('CaloriesConsumed ~ WeightGained', data = calories).fit()
model.summary()

pred1 = model.predict(pd.DataFrame(calories['WeightGained']))

# Regression Line
plt.scatter(calories.WeightGained, calories.CaloriesConsumed)
plt.plot(calories.WeightGained, pred1, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

# Error calculation
res1 = calories.CaloriesConsumed - pred1
res_sqr1 = res1 * res1
mse1 = np.mean(res_sqr1)
rmse1 = np.sqrt(mse1)
rmse1


######### Model building on Transformed Data
# Log Transformation
# x = log(waist); y = at

plt.scatter(x = np.log(calories['WeightGained']), y = calories['CaloriesConsumed'], color = 'brown')
np.corrcoef(np.log(calories.WeightGained), calories.CaloriesConsumed) #correlation

model2 = smf.ols('CaloriesConsumed ~ np.log(WeightGained)', data = calories).fit()
model2.summary()

pred2 = model2.predict(pd.DataFrame(calories['WeightGained']))

# Regression Line
plt.scatter(np.log(calories.WeightGained), calories.CaloriesConsumed)
plt.plot(np.log(calories.WeightGained), pred2, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

# Error calculation
res2 = calories.CaloriesConsumed - pred2
res_sqr2 = res2 * res2
mse2 = np.mean(res_sqr2)
rmse2 = np.sqrt(mse2)
rmse2


#### Exponential transformation
# x = WeightGained; y = log(CaloriesConsumed)

plt.scatter(x = calories['WeightGained'], y = np.log(calories['CaloriesConsumed']), color = 'orange')
np.corrcoef(calories.WeightGained, np.log(calories.CaloriesConsumed)) #correlation

model3 = smf.ols('np.log(CaloriesConsumed) ~ WeightGained', data = calories).fit()
model3.summary()

pred3 = model3.predict(pd.DataFrame(calories['WeightGained']))
pred3_at = np.exp(pred3)
pred3_at

# Regression Line
plt.scatter(calories.WeightGained, np.log(calories.CaloriesConsumed))
plt.plot(calories.WeightGained, pred3, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

# Error calculation
res3 = calories.CaloriesConsumed - pred3_at
res_sqr3 = res3 * res3
mse3 = np.mean(res_sqr3)
rmse3 = np.sqrt(mse3)
rmse3


#### Polynomial transformation
# x = WeightGained; x^2 = WeightGained*WeightGained; y = log(CaloriesConsumed)

model4 = smf.ols('np.log(CaloriesConsumed) ~ WeightGained + I(WeightGained*WeightGained)', data = calories).fit()
model4.summary()

pred4 = model4.predict(pd.DataFrame(calories))
pred4_at = np.exp(pred4)
pred4_at

# Regression line
from sklearn.preprocessing import PolynomialFeatures
poly_reg = PolynomialFeatures(degree = 2)
X = calories.iloc[:, 0:1].values
X_poly = poly_reg.fit_transform(X)
# y = calories.iloc[:, 1].values


plt.scatter(calories.WeightGained, np.log(calories.CaloriesConsumed))
plt.plot(X, pred4, color = 'red')
plt.legend(['Predicted line', 'Observed data'])
plt.show()


# Error calculation
res4 = calories.CaloriesConsumed - pred4_at
res_sqr4 = res4 * res4
mse4 = np.mean(res_sqr4)
rmse4 = np.sqrt(mse4)
rmse4


# Choose the best model using RMSE
data = {"MODEL":pd.Series(["SLR", "Log model", "Exp model", "Poly model"]), "RMSE":pd.Series([rmse1, rmse2, rmse3, rmse4])}
table_rmse = pd.DataFrame(data)
table_rmse

####################
## The best model ##

from sklearn.model_selection import train_test_split

train, test = train_test_split(calories, test_size = 0.2)

finalmodel = smf.ols('np.log(CaloriesConsumed) ~ WeightGained + I(WeightGained*WeightGained)', data = train).fit()
finalmodel.summary()

# Predict on test data
test_pred = finalmodel.predict(pd.DataFrame(test))
pred_test_CaloriesConsumed = np.exp(test_pred)
pred_test_CaloriesConsumed

# Model Evaluation on Test data
test_res = test.CaloriesConsumed - pred_test_CaloriesConsumed
test_sqrs = test_res * test_res
test_mse = np.mean(test_sqrs)
test_rmse = np.sqrt(test_mse)
test_rmse


# Prediction on train data
train_pred = finalmodel.predict(pd.DataFrame(train))
pred_train_CaloriesConsumed = np.exp(train_pred)
pred_train_CaloriesConsumed

# Model Evaluation on train data
train_res = train.CaloriesConsumed - pred_train_CaloriesConsumed
train_sqrs = train_res * train_res
train_mse = np.mean(train_sqrs)
train_rmse = np.sqrt(train_mse)
train_rmse












