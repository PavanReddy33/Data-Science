import pandas as pd

ecg = pd.read_excel(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\SURVIVAL ANALYTICS\Datasets_Survival Analytics\ECG_Surv.xlsx")
ecg.head()
ecg.describe()

ecg["survival_time_hr"].describe()

ecg.drop(["age"],axis=1,inplace=True)
ecg.drop(["fractionalshortening"],axis=1,inplace=True)
ecg.drop(["epss"],axis=1,inplace=True)
ecg.drop(["lvdd"],axis=1,inplace=True)
ecg.drop(["wallmotion-score"],axis=1,inplace=True)
ecg.drop(["wallmotion-index"],axis=1,inplace=True)
ecg.drop(["multi_sensor"],axis=1,inplace=True)
ecg.drop(["name"],axis=1,inplace=True)
ecg.drop(["group"],axis=1,inplace=True)

# survival_time_hr is referring to time 
T = ecg.survival_time_hr

# Importing the KaplanMeierFitter model to fit the survival analysis
from lifelines import KaplanMeierFitter

# Initiating the KaplanMeierFitter model
kmf = KaplanMeierFitter()

# Fitting KaplanMeierFitter model on Time and Events
kmf.fit(T, event_observed=ecg.alive)

# Time-line estimations plot 
kmf.plot()

# Over Multiple groups 
ecg.pericardialeffusion.value_counts()

# Applying KaplanMeierFitter model on Time and Events for the group "1"
kmf.fit(T[ecg.pericardialeffusion==1], ecg.alive[ecg.pericardialeffusion==1], label='1')
ax = kmf.plot()

# Applying KaplanMeierFitter model on Time and Events for the group "0"
kmf.fit(T[ecg.pericardialeffusion==0], ecg.alive[ecg.pericardialeffusion==0], label='0')
kmf.plot(ax=ax)
