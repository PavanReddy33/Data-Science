pip install lifelines
# import lifelines

import pandas as pd
# Loading the the survival un-employment data
patient = pd.read_csv(r"C:\Users\pavva\OneDrive\Documents\DATA SCIENCE\SURVIVAL ANALYTICS\Datasets_Survival Analytics\Patient.csv")
patient.head()
patient.describe()

patient = patient.iloc[:,1:]

patient["Followup"].describe()

# Spell is referring to time 
T = patient.Followup

# Importing the KaplanMeierFitter model to fit the survival analysis
from lifelines import KaplanMeierFitter

# Initiating the KaplanMeierFitter model
kmf = KaplanMeierFitter()

# Fitting KaplanMeierFitter model on Followup and Eventtype for death 
kmf.fit(T, event_observed=patient.Eventtype)

# Time-line estimations plot 
kmf.plot()

# Over Multiple groups 
# For each group, here group is ui
patient.Scenario.value_counts()

kmf.fit(T[patient.Eventtype==1], patient.Eventtype[patient.Eventtype==1], label='1')
ax = kmf.plot()

# Applying KaplanMeierFitter model on Time and Events for the group "0"
kmf.fit(T[patient.Eventtype==0], patient.Eventtype[patient.Eventtype==0], label='0')
kmf.plot(ax=ax)
